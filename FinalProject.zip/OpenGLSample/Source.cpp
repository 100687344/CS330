﻿//copy of final project code.
//this is to be used to test new concepts
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "shader.h"
#include "camera.h"
#include<vector>
#include <iostream>


void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void processInput(GLFWwindow *window);

// settings
const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;

//Lights
float xlight = 1.2f, ylight = 1.0f, zlight = 2.0f;


// camera
glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 3.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

bool firstMouse = true;
bool orthoView = false; //Am I viewing the world in an orthographic view?
float yaw = -90.0f;	// yaw is initialized to -90.0 degrees since a yaw of 0.0 results in a direction vector pointing to the right so we initially rotate a bit to the left.
float pitch = 0.0f;
float lastX = 800.0f / 2.0;
float lastY = 600.0 / 2.0;
float fov = 45.0f;
float cameraSpeed = 4;

// timing
float deltaTime = 0.0f;	// time between current frame and last frame
float lastFrame = 0.0f;

//lighting
glm::vec3 lightPos(1.2f, 1.0f, 2.0f);

int main()
{
	// glfw: initialize and configure
	// ------------------------------
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// glfw window creation
	// --------------------
	GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "House", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	glfwSetCursorPosCallback(window, mouse_callback);
	glfwSetScrollCallback(window, scroll_callback);

	// tell GLFW to capture our mouse
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// glad: load all OpenGL function pointers
	// ---------------------------------------
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	// configure global opengl state
	// -----------------------------
	glEnable(GL_DEPTH_TEST);

	// build and compile our shader zprogram
	// ------------------------------------
	Shader ourShader("shaderfiles/7.1.camera.vs", "shaderfiles/7.1.camera.fs");

	//Lighting Shader
	Shader lightingShader("shaderfiles/2.2.basic_lighting.vs", "shaderfiles/2.2.basic_lighting.fs");
	Shader lightCubeShader("shaderfiles/2.2.light_cube.vs", "shaderfiles/2.2.light_cube.fs");

	
	struct Object {
		unsigned int vertexBuffer;
		unsigned int texcoordBuffer;
		unsigned int normalsBuffer;
		unsigned int VAO;
		std::vector<glm::vec3> vertices;
		std::vector<glm::vec2> texcoords;
		std::vector<glm::vec3> normals;
		void upload() {
			generateFlatNorms();
			glGenVertexArrays(1, &VAO);
			glGenBuffers(1, &vertexBuffer);
			glGenBuffers(1, &texcoordBuffer);
			glGenBuffers(1, &normalsBuffer);
			glBindVertexArray(VAO);
			//upload vertex buffer
			glBindBuffer(GL_ARRAY_BUFFER, vertexBuffer);
			glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(glm::vec3), vertices.data(), GL_STATIC_DRAW);
			//upload texcoord buffer
			glBindBuffer(GL_ARRAY_BUFFER, texcoordBuffer);
			glBufferData(GL_ARRAY_BUFFER, texcoords.size() * sizeof(glm::vec2), texcoords.data(), GL_STATIC_DRAW);
			//upload normals buffer
			glBindBuffer(GL_ARRAY_BUFFER, normalsBuffer);
			glBufferData(GL_ARRAY_BUFFER, normals.size() * sizeof(glm::vec3), normals.data(), GL_STATIC_DRAW);
			
			// position attribute
			glBindBuffer(GL_ARRAY_BUFFER, vertexBuffer);
			glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
			glEnableVertexAttribArray(0);
			// texture coord attribute
			glBindBuffer(GL_ARRAY_BUFFER, texcoordBuffer);
			glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), (void*)0);
			glEnableVertexAttribArray(1);
			//normals attribute
			glBindBuffer(GL_ARRAY_BUFFER, normalsBuffer);
			glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
			glEnableVertexAttribArray(2);
		}
		void cleanUp() {
			// optional: de-allocate all resources once they've outlived their purpose:
			// ------------------------------------------------------------------------
			glDeleteVertexArrays(1, &VAO);
			glDeleteBuffers(1, &vertexBuffer);
			glDeleteBuffers(1, &texcoordBuffer);
			glDeleteBuffers(1, &normalsBuffer);
		}
		void draw(glm::mat4 model, Shader currentShader, unsigned int texture) {
			// render boxes
			glBindVertexArray(VAO);
			// calculate the model matrix for each object and pass it to shader before drawing

			currentShader.setMat4("model", model);

			// bind textures on corresponding texture units
			glActiveTexture(GL_TEXTURE0);
			glBindTexture(GL_TEXTURE_2D, texture);

			glDrawArrays(GL_TRIANGLES, 0, vertices.size());
		}
		void generateFlatNorms()
		{
			normals.resize(vertices.size());
			for (size_t i = 0; i < vertices.size()/3; i++)
			{
				glm::vec3 p0 = vertices[i * 3 + 0];
				glm::vec3 p1 = vertices[i * 3 + 1];
				glm::vec3 p2 = vertices[i * 3 + 2];

				glm::vec3 e0 = glm::normalize(p1 - p0);
				glm::vec3 e1 = glm::normalize(p2 - p0);

				glm::vec3 n = glm::cross(e0, e1);

				normals[i * 3 + 0] = n;
				normals[i * 3 + 1] = n;
				normals[i * 3 + 2] = n;
			}
		}
	};
	Object plane; //
	Object porch; //
	Object singleGarage;
	Object doubleGarage;
	Object siding;
	Object firstFloorRoof; //
	Object porchCol;
	Object smallCol;
	Object firstFloorBrick; //
	Object secondFloor; //
	Object frontStairs;
	Object garage;
	Object firstFloorSiding;
	Object secondFloorRoof;
	Object windowPyramidBig;
	Object windowPyramidSmall;
	Object porchPyramid;
	Object garagePyramid;
	Object mulch;
	Object porchFence;
	Object windowsLR;
	Object windowsUD;
	Object frontDoor;
	Object backStairs;
	Object garageDoors;
	Object backDoor;
	Object bushes;
	Object pyramid;//used for testing

	firstFloorBrick.vertices = {
		//front left face -- front window and door
		glm::vec3(0.0f, 0.0f, 5.0f),//bottom left point
		glm::vec3(5.0f, 0.0f, 5.0f),//bottom right point
		glm::vec3(5.0f, 2.0f, 5.0f),//top right point
		glm::vec3(5.0f, 2.0f, 5.0f),//top right point
		glm::vec3(0.0f, 2.0f, 5.0f),//top left point
		glm::vec3(0.0f, 0.0f, 5.0f),//bottom left point
		
		//front front middle face -- small side on porch near garage
		glm::vec3(5.0f, 0.0f, 5.0f),//bottom left point
		glm::vec3(5.0f, 0.0f, 5.75f),//bottom right point
		glm::vec3(5.0f, 2.0f, 5.75),//top right point
		glm::vec3(5.0f, 2.0f, 5.75),//top right point
		glm::vec3(5.0f, 2.0f, 5.0f),//top left point
		glm::vec3(5.0f, 0.0f, 5.0f),//bottom left point

		//front middle face -- single car garage
		glm::vec3(5.0f, 0.0f, 5.75f),//bottom left point
		glm::vec3(7.0f, 0.0f, 5.75f),//bottom right point
		glm::vec3(7.0f, 2.0f, 5.75f),//top right point
		glm::vec3(7.0f, 2.0f, 5.75f),//top right point
		glm::vec3(5.0f, 2.0f, 5.75f),//top left point
		glm::vec3(5.0f, 0.0f, 5.75f),//bottom left point

		//front right face -- small segment between garage
		glm::vec3(7.0f, 0.0f, 5.75f),//bottom left point
		glm::vec3(7.0f, 0.0f, 6.0f),//bottom right point
		glm::vec3(7.0f, 2.0f, 6.0f),//top right point
		glm::vec3(7.0f, 2.0f, 6.0f),//top right point
		glm::vec3(7.0f, 2.0f, 5.75f),//top left point
		glm::vec3(7.0f, 0.0f, 5.75f),//bottom left point

		//front right face -- double car garage
		glm::vec3(7.0f, 0.0f, 6.0f),//bottom left point
		glm::vec3(10.0f, 0.0f, 6.0f),//bottom right point
		glm::vec3(10.0f, 2.0f, 6.0f),//top right point
		glm::vec3(10.0f, 2.0f, 6.0f),//top right point
		glm::vec3(7.0f, 2.0f, 6.0f),//top left point
		glm::vec3(7.0f, 0.0f, 6.0f),//bottom left point
	};
	firstFloorSiding.vertices = {
		//back face -- back of house
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left point
		glm::vec3(10.0f, 0.0f, 0.0f),//bottom right point
		glm::vec3(10.0f, 2.0f, 0.0f),//top right point
		glm::vec3(10.0f, 2.0f, 0.0f),//top right point
		glm::vec3(0.0f, 2.0f, 0.0f),//top left point
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left point

		//left side face
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left
		glm::vec3(0.0f, 0.0f, 5.0f),//bottom right
		glm::vec3(0.0f, 2.0f, 5.0f),//top right
		glm::vec3(0.0f, 2.0f, 5.0f),//top right
		glm::vec3(0.0f, 2.0f, 0.0f),//top left
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left

		//right side face
		glm::vec3(10.0f, 0.0f, 0.0f),//bottom left
		glm::vec3(10.0f, 0.0f, 6.0f),//bottom right
		glm::vec3(10.0f, 2.0f, 6.0f),//top right
		glm::vec3(10.0f, 2.0f, 6.0f),//top right
		glm::vec3(10.0f, 2.0f, 0.0f),//top left
		glm::vec3(10.0f, 0.0f, 0.0f),//bottom left

		//above single garage
		glm::vec3(5.35f, 1.25f, 5.76f),//bottom left
		glm::vec3(6.65f, 1.25f, 5.76f),//bottom right
		glm::vec3(6.65f, 2.0f, 5.76f),//top right
		glm::vec3(6.65f, 2.0f, 5.76f),//top right
		glm::vec3(5.35f, 2.0f, 5.76f),//top left
		glm::vec3(5.35f, 1.25f, 5.76f),//bottom left

		//above double garage
		glm::vec3(7.35f, 1.25f, 6.01f),//bottom left
		glm::vec3(9.65f, 1.25f, 6.01f),//bottom right
		glm::vec3(9.65f, 2.0f, 6.01f),//top right
		glm::vec3(9.65f, 2.0f, 6.01f),//top right
		glm::vec3(7.35f, 2.0f, 6.01f),//top left
		glm::vec3(7.35f, 1.25f, 6.01f),//bottom left
	};
	firstFloorRoof.vertices = {

		//left face
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left point
		glm::vec3(0.0f, 0.0f, 0.375f),//bottom right point
		glm::vec3(1.0f, 0.5f, 0.375f),//top right point
		glm::vec3(1.0f, 0.5f, 0.375f),//top right point
		glm::vec3(1.0f, 0.5f, 0.0f),//top left point
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left point

		//left corner
		glm::vec3(0.0f, 0.0f, 0.375f),//bottom left point
		glm::vec3(0.0f, 0.0f, 1.0f),//bottom right point
		glm::vec3(1.0f, 0.5f, 0.375f),//top right point
		glm::vec3(0.0f, 0.0f, 1.0f),//top right point
		glm::vec3(1.0f, 0.0f, 1.0f),//top left point
		glm::vec3(1.0f, 0.5f, 0.375f),//bottom left point

		//under left window
		glm::vec3(1.0f, 0.0f, 1.0f),//bottom left point
		glm::vec3(2.0f, 0.0f, 1.0f),//bottom right point
		glm::vec3(2.0f, 0.5f, 0.375f),//top right point
		glm::vec3(2.0f, 0.5f, 0.375f),//top right point
		glm::vec3(1.0f, 0.5f, 0.375f),//top left point
		glm::vec3(1.0f, 0.0f, 1.0f),//bottom left point

		//under left window to the right
		glm::vec3(2.0f, 0.0f, 1.0f),//bottom left point
		glm::vec3(2.5f, 0.0f, 1.0f),//bottom right point
		glm::vec3(2.5f, 0.8f, 0.0f),//top right point
		glm::vec3(2.5f, 0.8f, 0.0f),//top right point
		glm::vec3(2.0f, 0.8f, 0.0f),//top left point
		glm::vec3(2.0f, 0.0f, 1.0f),//bottom left point

		//middle roof
		glm::vec3(2.5f, 0.0f, 1.0f),//bottom left point
		glm::vec3(5.0f, 0.0f, 1.0f),//bottom right point
		glm::vec3(5.0f, 1.1f, -0.375f),//top right point
		glm::vec3(5.0f, 1.1f, -0.375f),//top right point
		glm::vec3(2.5f, 1.1f, -0.375f),//top left point
		glm::vec3(2.5f, 0.0f, 1.0f),//bottom left point

		//under right window to the left
		glm::vec3(5.0f, 0.0f, 1.0f),//bottom left point
		glm::vec3(5.5f, 0.0f, 1.0f),//bottom right point
		glm::vec3(5.5f, 0.8f, 0.0f),//top right point
		glm::vec3(5.5f, 0.8f, 0.0f),//top right point
		glm::vec3(5.0f, 0.8f, 0.0f),//top left point
		glm::vec3(5.0f, 0.0f, 1.0f),//bottom left point

		//under right window
		glm::vec3(5.5f, 0.0f, 1.0f),//bottom left point
		glm::vec3(6.5f, 0.0f, 1.0f),//bottom right point
		glm::vec3(6.5f, 0.5f, 0.375f),//top right point
		glm::vec3(6.5f, 0.5f, 0.375f),//top right point
		glm::vec3(5.5f, 0.5f, 0.375f),//top left point
		glm::vec3(5.5f, 0.0f, 1.0f),//bottom left point

		//under right window to the right
		glm::vec3(6.5f, 0.0f, 1.0f),//bottom left point
		glm::vec3(7.25f, 0.0f, 1.0f),//bottom right point
		glm::vec3(7.25f, 0.8f, 0.0f),//top right point
		glm::vec3(7.25f, 0.8f, 0.0f),//top right point
		glm::vec3(6.5f, 0.8f, 0.0f),//top left point
		glm::vec3(6.5f, 0.0f, 1.0f),//bottom left point

		//right corner
		glm::vec3(7.25f, 2.0f, -1.5f),//bottom left point
		glm::vec3(7.25f, 0.0f, 1.0f),//bottom right point
		glm::vec3(10.5f, 0.0f, 1.0f),//top right point
		glm::vec3(10.5f, 0.0f, 1.0f),//top right point
		glm::vec3(10.5f, 0.0f, -5.25f),//top left point
		glm::vec3(7.25f, 2.0f, -1.5f),//bottom left point

		//back face
		glm::vec3(10.5f, 0.0f, -5.25f),//bottom left point
		glm::vec3(7.25f, 0.0f, -5.25f),//bottom right point
		glm::vec3(7.25f, 2.0f, -1.5f),//top right point
	};
	secondFloor.vertices = {
		//back face -- back of house
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left point
		glm::vec3(7.0f, 0.0f, 0.0f),//bottom right point
		glm::vec3(7.0f, 2.0f, 0.0f),//top right point
		glm::vec3(7.0f, 2.0f, 0.0f),//top right point
		glm::vec3(0.0f, 2.0f, 0.0f),//top left point
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left point

		//left face
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left point
		glm::vec3(0.0f, 0.0f, 5.0f),//bottom right point
		glm::vec3(0.0f, 2.0f, 5.0f),//top right point
		glm::vec3(0.0f, 2.0f, 5.0f),//top right point
		glm::vec3(0.0f, 2.0f, 0.0f),//top left point
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left point

		//front face -- left of window
		glm::vec3(0.0f, 0.0f, 5.0f),//bottom left point
		glm::vec3(0.75f, 0.0f, 5.0f),//bottom right point
		glm::vec3(0.75f, 2.0f, 5.0),//top right point
		glm::vec3(0.75f, 2.0f, 5.0),//top right point
		glm::vec3(0.0f, 2.0f, 5.0f),//top left point
		glm::vec3(0.0f, 0.0f, 5.0f),//bottom left point

		//front face -- left side of window
		glm::vec3(0.75f, 0.0f, 5.0f),//bottom left point
		glm::vec3(0.75f, 0.0f, 5.375f),//bottom right point
		glm::vec3(0.75f, 2.0f, 5.375f),//top right point
		glm::vec3(0.75f, 2.0f, 5.375f),//top right point
		glm::vec3(0.75f, 2.0f, 5.0f),//top left point
		glm::vec3(0.75f, 0.0f, 5.0f),//bottom left point

		//front face -- left window
		glm::vec3(0.75f, 0.0f, 5.375f),//bottom left point
		glm::vec3(1.75f, 0.0f, 5.375f),//bottom right point
		glm::vec3(1.75f, 2.0f, 5.375f),//top right point
		glm::vec3(1.75f, 2.0f, 5.375f),//top right point
		glm::vec3(0.75f, 2.0f, 5.375f),//top left point
		glm::vec3(0.75f, 0.0f, 5.375f),//bottom left point

		//front face -- right side of window
		glm::vec3(1.75f, 0.0f, 5.375f),//bottom left point
		glm::vec3(1.75f, 0.0f, 5.0f),//bottom right point
		glm::vec3(1.75f, 2.0f, 5.0f),//top right point
		glm::vec3(1.75f, 2.0f, 5.0f),//top right point
		glm::vec3(1.75f, 2.0f, 5.375f),//top left point
		glm::vec3(1.75f, 0.0f, 5.375f),//bottom left point

		//front face -- right of window
		glm::vec3(1.75f, 0.0f, 5.0f),//bottom left
		glm::vec3(2.25f, 0.0f, 5.0f),//bottom right
		glm::vec3(2.25f, 2.0f, 5.0f),//top right
		glm::vec3(2.25f, 2.0f, 5.0f),//top right
		glm::vec3(1.75f, 2.0f, 5.0f),//top left
		glm::vec3(1.75f, 0.0f, 5.0f),//bottom left

		//front face -- going back to middle
		glm::vec3(2.25f, 0.0f, 5.0f),//bottom left
		glm::vec3(2.25f, 0.0f, 4.625f),//bottom right
		glm::vec3(2.25f, 2.0f, 4.625f),//top right
		glm::vec3(2.25f, 2.0f, 4.625f),//top right
		glm::vec3(2.25f, 2.0f, 5.0f),//top left
		glm::vec3(2.25f, 0.0f, 5.0f),//bottom left

		//front face -- middle
		glm::vec3(2.25f, 0.0f, 4.625f),//bottom left
		glm::vec3(4.75f, 0.0f, 4.625f),//bottom right
		glm::vec3(4.75f, 2.0f, 4.625f),//top right
		glm::vec3(4.75f, 2.0f, 4.625f),//top right
		glm::vec3(2.25f, 2.0f, 4.625f),//top left
		glm::vec3(2.25f, 0.0f, 4.625f),//bottom left

		//front face -- going back to middle
		glm::vec3(4.75f, 0.0f, 5.0f),//bottom left
		glm::vec3(4.75f, 0.0f, 4.625f),//bottom right
		glm::vec3(4.75f, 2.0f, 4.625f),//top right
		glm::vec3(4.75f, 2.0f, 4.625f),//top right
		glm::vec3(4.75f, 2.0f, 5.0f),//top left
		glm::vec3(4.75f, 0.0f, 5.0f),//bottom left

		//front face -- left of right window
		glm::vec3(4.75f, 0.0f, 5.0f),//bottom left
		glm::vec3(5.25f, 0.0f, 5.0f),//bottom right
		glm::vec3(5.25f, 2.0f, 5.0f),//top right
		glm::vec3(5.25f, 2.0f, 5.0f),//top right
		glm::vec3(4.75f, 2.0f, 5.0f),//top left
		glm::vec3(4.75f, 0.0f, 5.0f),//bottom left

		//front face -- left side of window
		glm::vec3(5.25f, 0.0f, 5.375f),//bottom left point
		glm::vec3(5.25f, 0.0f, 5.0f),//bottom right point
		glm::vec3(5.25f, 2.0f, 5.0f),//top right point

		glm::vec3(5.25f, 2.0f, 5.0f),//top right point
		glm::vec3(5.25f, 2.0f, 5.375f),//top left point
		glm::vec3(5.25f, 0.0f, 5.375f),//bottom left point

		//front face -- right window
		glm::vec3(5.25f, 0.0f, 5.375f),//bottom left point
		glm::vec3(6.25f, 0.0f, 5.375f),//bottom right point
		glm::vec3(6.25f, 2.0f, 5.375f),//top right point
		glm::vec3(6.25f, 2.0f, 5.375f),//top right point
		glm::vec3(5.25f, 2.0f, 5.375f),//top left point
		glm::vec3(5.25f, 0.0f, 5.375f),//bottom left point

		//front face -- left side of window
		glm::vec3(6.25f, 0.0f, 5.375f),//bottom left point
		glm::vec3(6.25f, 0.0f, 5.0f),//bottom right point
		glm::vec3(6.25f, 2.0f, 5.0f),//top right point
		glm::vec3(6.25f, 2.0f, 5.0f),//top right point
		glm::vec3(6.25f, 2.0f, 5.375f),//top left point
		glm::vec3(6.25f, 0.0f, 5.375f),//bottom left point

		//front face -- right of right window
		glm::vec3(6.25f, 0.0f, 5.0f),//bottom left point
		glm::vec3(7.0f, 0.0f, 5.0f),//bottom right point
		glm::vec3(7.0f, 2.0f, 5.0),//top right point
		glm::vec3(7.0f, 2.0f, 5.0),//top right point
		glm::vec3(6.25f, 2.0f, 5.0f),//top left point
		glm::vec3(6.25f, 0.0f, 5.0f),//bottom left point

		//left face
		glm::vec3(7.0f, 0.0f, 0.0f),//bottom left point
		glm::vec3(7.0f, 0.0f, 5.0f),//bottom right point
		glm::vec3(7.0f, 2.0f, 5.0f),//top right point
		glm::vec3(7.0f, 2.0f, 5.0f),//top right point
		glm::vec3(7.0f, 2.0f, 0.0f),//top left point
		glm::vec3(7.0f, 0.0f, 0.0f),//bottom left point
	};
	secondFloorRoof.vertices = {
		//left face
		glm::vec3(0.0f, 0.0f, -0.25f),//bottom left point
		glm::vec3(0.0f, 0.0f, 5.125f),//bottom right point
		glm::vec3(2.75f, 1.0f, 2.25f),//top right point (middle)

		//right face
		glm::vec3(7.5f, 0.0f, 5.125f),//top right point
		glm::vec3(7.5f, 0.0f, -0.25f),//top left point
		glm::vec3(4.75f, 1.0f, 2.25f),//bottom left point

		//back face
		glm::vec3(2.75f, 1.0f, 2.25f),//bottom left point
		glm::vec3(4.75f, 1.0f, 2.25f),//bottom right point
		glm::vec3(7.5f, 0.0f, -0.25f),//top right point
		glm::vec3(7.5f, 0.0f, -0.25f),//top right point
		glm::vec3(0.0f, 0.0f, -0.25f),//top left point
		glm::vec3(2.75f, 1.0f, 2.25f),//bottom left point

		//front face
		glm::vec3(0.0f, 0.0f, 5.125f),//bottom left point
		glm::vec3(7.5f, 0.0f, 5.125f),//bottom right point
		glm::vec3(4.75f, 1.0f, 2.25f),//top right point
		glm::vec3(4.75f, 1.0f, 2.25f),//top right point
		glm::vec3(2.75f, 1.0f, 2.25f),//top left point
		glm::vec3(0.0f, 0.0f, 5.125f),//bottom left point
	};
	windowPyramidBig.vertices = {
		//big pyramid under left window --how tall are these pyramids? MAGIC QUESTION....break out the trig functions
		//front face -- left window
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left point
		glm::vec3(2.75f, 0.0f, 0.0f),//bottom right point
		glm::vec3(1.51f, 0.548f, -0.75f),//top right point (middle)

		//left face -- left window
		glm::vec3(0.0f, 0.0f, -2.5f),//bottom left
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom right
		glm::vec3(1.51f, 0.548f, -0.75f),//top right point
		glm::vec3(1.51f, 0.548f, -0.75f),//top right point
		glm::vec3(1.51f, 0.548f, -2.5f),//top left point
		glm::vec3(0.0f, 0.0f, -2.5f),//bottom left point

		//right face -- left window
		glm::vec3(2.75f, 0.0f, 0.0f),//bottom left
		glm::vec3(2.75f, 0.0f, -2.5f),//bottom right
		glm::vec3(1.51f, 0.548f, -2.5f),//top right point
		glm::vec3(1.51f, 0.548f, -2.5f),//top right point
		glm::vec3(1.51f, 0.548f, -0.75f),//top left point
		glm::vec3(2.75f, 0.0f, 0.0f),//bottom left point

		//front face -- right window
		glm::vec3(4.75f, 0.0f, 0.0f),//bottom left point
		glm::vec3(7.5f, 0.0f, 0.0f),//bottom right point
		glm::vec3(5.99f, 0.548f, -0.75f),//top right point (middle)

		//left face -- right window
		glm::vec3(4.75f, 0.0f, -2.5f),//bottom left
		glm::vec3(4.75f, 0.0f, 0.0f),//bottom right
		glm::vec3(5.99f, 0.548f, -0.75f),//top right point
		glm::vec3(5.99f, 0.548f, -0.75f),//top right point
		glm::vec3(5.99f, 0.548f, -2.5f),//top left point
		glm::vec3(4.75f, 0.0f, -2.5f),//bottom left point

		//right face -- right window
		glm::vec3(7.5f, 0.0f, 0.0f),//bottom left
		glm::vec3(7.5f, 0.0f, -2.5f),//bottom right
		glm::vec3(5.99f, 0.548f, -2.5f),//top right point
		glm::vec3(5.99f, 0.548f, -2.5f),//top right point
		glm::vec3(5.99f, 0.548f, -0.75f),//top left point
		glm::vec3(7.5f, 0.0f, 0.0f),//bottom left point

	};
	windowPyramidSmall.vertices = {
		//front face -- left window
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left point
		glm::vec3(1.5f, 0.0f, 0.0f),//bottom right point
		glm::vec3(0.75f, 0.35f, -0.75f),//top right point (middle)

		//left face -- left window
		glm::vec3(0.0f, 0.0f, -1.0f),//bottom left
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom right
		glm::vec3(0.75f, 0.35f, -0.75f),//top right point
		glm::vec3(0.75f, 0.35f, -0.75f),//top right point
		glm::vec3(0.75f, 0.35f, -1.0f),//top left point
		glm::vec3(0.0f, 0.0f, -1.0f),//bottom left point

		//right face -- left window
		glm::vec3(1.5f, 0.0f, 0.0f),//bottom left
		glm::vec3(1.5f, 0.0f, -1.0f),//bottom right
		glm::vec3(0.75f, 0.35f, -1.0f),//top right point
		glm::vec3(0.75f, 0.35f, -1.0f),//top right point
		glm::vec3(0.75f, 0.35f, -0.75f),//top left point
		glm::vec3(1.5f, 0.0f, 0.0f),//bottom left point

		//front face -- right window
		glm::vec3(4.5f, 0.0f, 0.0f),//bottom left point
		glm::vec3(6.0f, 0.0f, 0.0f),//bottom right point
		glm::vec3(5.25f, 0.35f, -0.75f),//top right point (middle)

		//left face -- right window
		glm::vec3(4.5f, 0.0f, -1.0f),//bottom left
		glm::vec3(4.5f, 0.0f, 0.0f),//bottom right
		glm::vec3(5.25f, 0.35f, -0.75f),//top right point
		glm::vec3(5.25f, 0.35f, -0.75f),//top right point
		glm::vec3(5.25f, 0.35f, -1.0f),//top left point
		glm::vec3(4.5f, 0.0f, -1.0f),//bottom left point

		//right face -- right window
		glm::vec3(6.0f, 0.0f, 0.0f),//bottom left
		glm::vec3(6.0f, 0.0f, -1.0f),//bottom right
		glm::vec3(5.25f, 0.35f, -1.0f),//top right point
		glm::vec3(5.25f, 0.35f, -1.0f),//top right point
		glm::vec3(5.25f, 0.35f, -0.75f),//top left point
		glm::vec3(6.0f, 0.0f, 0.0f),//bottom left point
	};
	plane.vertices = {
		glm::vec3(-10.0f, -1.0f, -10.0f),//todo: comment these
		glm::vec3(10.0f, -1.0f, -10.0f),//todo: comment these
		glm::vec3(10.0f, -1.0f, 10.0f),//todo: comment these
		glm::vec3(10.0f, -1.0f, 10.0f),//todo: comment these
		glm::vec3(-10.0f, -1.0f, 10.0f),//todo: comment these
		glm::vec3(-10.0f, -1.0f, -10.0f),//todo: comment these
	};
	porch.vertices = {
		//front cube face
		glm::vec3(-5.0f, 0.0f, 0.75f),//bottom left point
		glm::vec3(0.0f, 0.0f, 0.75f),//bottom right point
		glm::vec3(0.0f, 0.5f, 0.75f),//top right point
		glm::vec3(0.0f, 0.5f, 0.75f),//top right point
		glm::vec3(-5.0f, 0.5f, 0.75f),//top left point
		glm::vec3(-5.0f, 0.0f, 0.75f),//bottom left point

		//left cube face
		glm::vec3(-5.0f, 0.5f, 0.75f),//bottom left
		glm::vec3(-5.0f, 0.5f, 0.0f),//bottom right
		glm::vec3(-5.0f, 0.0f, 0.0f),//top right
		glm::vec3(-5.0f, 0.0f, 0.0f),//top right
		glm::vec3(-5.0f, 0.0f, 0.75f),//top left
		glm::vec3(-5.0f, 0.5f, 0.75f),//bottom left

		//top cube face
		glm::vec3(-5.0f, 0.5f, 0.0f),//bottom left
		glm::vec3(0.0f, 0.5f, 0.0f),//bottom right
		glm::vec3(0.0f, 0.5f, 0.75f),//top right
		glm::vec3(0.0f, 0.5f, 0.75f),//top right
		glm::vec3(-5.0f, 0.5f, 0.75f),//top left
		glm::vec3(-5.0f, 0.5f, 0.0f),//bottom left
	};
	singleGarage.vertices = {
		//back cube face 
		glm::vec3(-2.5f, -1.5f, -1.0f),//bottom left point
		glm::vec3(2.5f, -1.5f, -1.0f),//bottom right point
		glm::vec3(2.5f, 1.5f, -1.0f),//top right point
		glm::vec3(2.5f, 1.5f, -1.0f),//top right point
		glm::vec3(-2.5f, 1.5f, -1.0f),//top left point
		glm::vec3(-2.5f, -1.5f, -1.0f),//bottom left point

		//front cube face
		glm::vec3(-2.5f, -1.5f, 1.0f),//bottom left point
		glm::vec3(2.5f, -1.5f, 1.0f),//bottom right point
		glm::vec3(2.5f, 1.5f, 1.0f),//top right point
		glm::vec3(2.5f, 1.5f, 1.0f),//top right point
		glm::vec3(-2.5f, 1.5f, 1.0f),//top left point
		glm::vec3(-2.5f, -1.5f, 1.0f),//bottom left point

		//left cube face
		glm::vec3(-2.5f, 1.5f, 1.0f),//bottom left
		glm::vec3(-2.5f, 1.5f, -1.0f),//bottom right
		glm::vec3(-2.5f, -1.5f, -1.0f),//top right
		glm::vec3(-2.5f, -1.5f, -1.0f),//top right
		glm::vec3(-2.5f, -1.5f, 1.0f),//top left
		glm::vec3(-2.5f, 1.5f, 1.0f),//bottom left

		//right cube face
		glm::vec3(2.5f, 1.5f, 1.0f),//bottom left
		glm::vec3(2.5f, 1.5f, -1.0f),//bottom right
		glm::vec3(2.5f, -1.5f, -1.0f),//top right
		glm::vec3(2.5f, -1.5f, -1.0f),//top right
		glm::vec3(2.5f, -1.5f, 1.0f),//top left
		glm::vec3(2.5f, 1.5f, 1.0f),//bottom left

		//bottom cube face
		glm::vec3(-2.5f, -1.5f, -1.0f),//bottom left
		glm::vec3(2.5f, -1.5f, -1.0f),//bottom right
		glm::vec3(2.5f, -1.5f, 1.0f),//top right
		glm::vec3(2.5f, -1.5f, 1.0f),//top right
		glm::vec3(-2.5f, -1.5f, 1.0f),//top left
		glm::vec3(-2.5f, -1.5f, -1.0f),//bottom left

		//top cube face
		glm::vec3(-2.5f, 1.5f, -1.0f),//bottom left
		glm::vec3(2.5f, 1.5f, -1.0f),//bottom right
		glm::vec3(2.5f, 1.5f, 1.0f),//top right
		glm::vec3(2.5f, 1.5f, 1.0f),//top right
		glm::vec3(-2.5f, 1.5f, 1.0f),//top left
		glm::vec3(-2.5f, 1.5f, -1.0f),//bottom left
	};
	doubleGarage.vertices = {
		//back cube face 
		glm::vec3(-2.75f, -1.5f, -1.5f),//bottom left point
		glm::vec3(2.75f, -1.5f, -1.5f),//bottom right point
		glm::vec3(2.75f, 1.5f, -1.5f),//top right point
		glm::vec3(2.75f, 1.5f, -1.5f),//top right point
		glm::vec3(-2.75f, 1.5f, -1.5f),//top left point
		glm::vec3(-2.75f, -1.5f, -1.5f),//bottom left point

		//front cube face
		glm::vec3(-2.75f, -1.5f, 1.5f),//bottom left point
		glm::vec3(2.75f, -1.5f, 1.5f),//bottom right point
		glm::vec3(2.75f, 1.5f, 1.5f),//top right point
		glm::vec3(2.75f, 1.5f, 1.5f),//top right point
		glm::vec3(-2.75f, 1.5f, 1.5f),//top left point
		glm::vec3(-2.75f, -1.5f, 1.5f),//bottom left point

		//left cube face
		glm::vec3(-2.75f, 1.5f, 1.5f),//bottom left
		glm::vec3(-2.75f, 1.5f, -1.5f),//bottom right
		glm::vec3(-2.75f, -1.5f, -1.5f),//top right
		glm::vec3(-2.75f, -1.5f, -1.5f),//top right
		glm::vec3(-2.75f, -1.5f, 1.5f),//top left
		glm::vec3(-2.75f, 1.5f, 1.5f),//bottom left

		//right cube face
		glm::vec3(2.75f, 1.5f, 1.5f),//bottom left
		glm::vec3(2.75f, 1.5f, -1.5f),//bottom right
		glm::vec3(2.75f, -1.5f, -1.5f),//top right
		glm::vec3(2.75f, -1.5f, -1.5f),//top right
		glm::vec3(2.75f, -1.5f, 1.5f),//top left
		glm::vec3(2.75f, 1.5f, 1.5f),//bottom left

		//bottom cube face
		glm::vec3(-2.75f, -1.5f, -1.5f),//bottom left
		glm::vec3(2.75f, -1.5f, -1.5f),//bottom right
		glm::vec3(2.75f, -1.5f, 1.5f),//top right
		glm::vec3(2.75f, -1.5f, 1.5f),//top right
		glm::vec3(-2.75f, -1.5f, 1.5f),//top left
		glm::vec3(-2.75f, -1.5f, -1.5f),//bottom left

		//top cube face
		glm::vec3(-2.75f, 1.5f, -1.5f),//bottom left
		glm::vec3(2.75f, 1.5f, -1.5f),//bottom right
		glm::vec3(2.75f, 1.5f, 1.5f),//top right
		glm::vec3(2.75f, 1.5f, 1.5f),//top right
		glm::vec3(-2.75f, 1.5f, 1.5f),//top left
		glm::vec3(-2.75f, 1.5f, -1.5f),//bottom left
	};
	siding.vertices = {
		//FRONT PORCH OUTLET
		//left outlet face
		glm::vec3(0.375f, 0.5f, 5.0f),//bottom left point
		glm::vec3(0.75f, 0.5f, 5.375f),//bottom right point
		glm::vec3(0.75f, 2.0f, 5.375f),//top right point
		glm::vec3(0.75f, 2.0f, 5.375f),//top right point
		glm::vec3(0.375f, 2.0f, 5.0f),//top left point
		glm::vec3(0.375f, 0.5f, 5.0f),//bottom left point

		//front outlet face
		glm::vec3(0.75f, 0.5f, 5.375f),//bottom left point
		glm::vec3(1.75f, 0.5f, 5.375f),//bottom right point
		glm::vec3(1.75f, 2.0f, 5.375f),//top right point
		glm::vec3(1.75f, 2.0f, 5.375f),//top right point
		glm::vec3(0.75f, 2.0f, 5.375f),//top left point
		glm::vec3(0.75f, 0.5f, 5.375f),//bottom left point

		//right outlet face
		glm::vec3(1.75f, 0.5f, 5.375f),//bottom left
		glm::vec3(2.125f, 0.5f, 5.0f),//bottom right
		glm::vec3(2.125f, 2.0f, 5.0f),//top right
		glm::vec3(2.125f, 2.0f, 5.0f),//top right
		glm::vec3(1.75f, 2.0f, 5.375f),//top left
		glm::vec3(1.75f, 0.5f, 5.375f),//bottom left

		//master bedroom outlet
		//back face
		glm::vec3(0.0f, 3.0f, -0.25f),//bottom left
		glm::vec3(1.0f, 3.0f, -0.25f),//bottom right
		glm::vec3(1.0f, 4.0f, -0.25f),//top right
		glm::vec3(1.0f, 4.0f, -0.25f),//top right
		glm::vec3(0.0f, 4.0f, -0.25f),//top left
		glm::vec3(0.0f, 3.0f, -0.25f),//bottom left

		//left face
		glm::vec3(0.0f, 3.0f, -0.25f),//bottom left
		glm::vec3(0.0f, 3.0f, 0.0f),//bottom right
		glm::vec3(0.0f, 4.0f, 0.0f),//top right
		glm::vec3(0.0f, 4.0f, 0.0f),//top right
		glm::vec3(0.0f, 4.0f, -0.25f),//top left
		glm::vec3(0.0f, 3.0f, -0.25f),//bottom left

		//right face
		glm::vec3(1.0f, 3.0f, -0.25f),//bottom left
		glm::vec3(1.0f, 3.0f, 0.0f),//bottom right
		glm::vec3(1.0f, 4.0f, 0.0f),//top right
		glm::vec3(1.0f, 4.0f, 0.0f),//top right
		glm::vec3(1.0f, 4.0f, -0.25f),//top left
		glm::vec3(1.0f, 3.0f, -0.25f),//bottom left

		//bottom face
		glm::vec3(0.0f, 3.0f, -0.25f),//bottom left
		glm::vec3(1.0f, 3.0f, -0.25f),//bottom right
		glm::vec3(1.0f, 3.0f, 0.0f),//top right
		glm::vec3(1.0f, 3.0f, 0.0f),//top right
		glm::vec3(0.0f, 3.0f, 0.0f),//top left
		glm::vec3(0.0f, 3.0f, -0.25f),//bottom left

		//second floor outlet
		//back face
		glm::vec3(2.0f, 2.0f, -0.25f),//bottom left
		glm::vec3(7.0f, 2.0f, -0.25f),//bottom right
		glm::vec3(7.0f, 4.0f, -0.25f),//top right
		glm::vec3(7.0f, 4.0f, -0.25f),//top right
		glm::vec3(2.0f, 4.0f, -0.25f),//top left
		glm::vec3(2.0f, 2.0f, -0.25f),//bottom left

		//left face
		glm::vec3(2.0f, 2.0f, -0.25f),//bottom left
		glm::vec3(2.0f, 2.0f, 0.0f),//bottom right
		glm::vec3(2.0f, 4.0f, 0.0f),//top right
		glm::vec3(2.0f, 4.0f, 0.0f),//top right
		glm::vec3(2.0f, 4.0f, -0.25f),//top left
		glm::vec3(2.0f, 2.0f, -0.25f),//bottom left

		//right face
		glm::vec3(7.0f, 2.0f, -0.25f),//bottom left
		glm::vec3(7.0f, 2.0f, 0.0f),//bottom right
		glm::vec3(7.0f, 4.0f, 0.0f),//top right
		glm::vec3(7.0f, 4.0f, 0.0f),//top right
		glm::vec3(7.0f, 4.0f, -0.25f),//top left
		glm::vec3(7.0f, 2.0f, -0.25f),//bottom left

		//bottom face
		glm::vec3(2.0f, 2.0f, -0.25f),//bottom left
		glm::vec3(6.75f, 2.0f, -0.25f),//bottom right
		glm::vec3(6.75f, 2.0f, 0.0f),//top right
		glm::vec3(6.75f, 2.0f, 0.0f),//top right
		glm::vec3(2.0f, 2.0f, 0.0f),//top left
		glm::vec3(2.0f, 2.0f, -0.25f),//bottom left

		//kitchen outlet
		//left outlet face
		glm::vec3(2.925f, 0.0f, 0.0f),//bottom left point
		glm::vec3(3.3f, 0.0f, -0.25f),//bottom right point
		glm::vec3(3.3f, 2.0f, -0.25f),//top right point
		glm::vec3(3.3f, 2.0f, -0.25f),//top right point
		glm::vec3(2.925f, 2.0f, 0.0f),//top left point
		glm::vec3(2.925f, 0.0f, 0.0f),//bottom left point

		//front outlet face
		glm::vec3(3.3f, 0.0f, -0.25f),//bottom left point
		glm::vec3(4.3f, 0.0f, -0.25f),//bottom right point
		glm::vec3(4.3f, 2.0f, -0.25f),//top right point
		glm::vec3(4.3f, 2.0f, -0.25f),//top right point
		glm::vec3(3.3f, 2.0f, -0.25f),//top left point
		glm::vec3(3.3f, 0.0f, -0.25f),//bottom left point

		//right outlet face
		glm::vec3(4.675f, 0.0f, 0.0f),//bottom left
		glm::vec3(4.3f, 0.0f, -0.25f),//bottom right
		glm::vec3(4.3f, 2.0f, -0.25f),//top right
		glm::vec3(4.3f, 2.0f, -0.25f),//top right
		glm::vec3(4.675f, 2.0f, 0.0f),//top left
		glm::vec3(4.675f, 0.0f, 0.0f),//bottom left

		//SECOND FLOOR ROOF FLASHING
		glm::vec3(-0.25f, 4.0f, 4.875f),//bottom left
		glm::vec3(7.25f, 4.0f, 4.875f),//bottom right
		glm::vec3(7.25f, 4.0f, -0.5f),//top right
		glm::vec3(7.25f, 4.0f, -0.5f),//top right
		glm::vec3(-0.25f, 4.0f, -0.5f),//top left
		glm::vec3(-0.25f, 4.0f, 4.875f),//bottom left

		//big pyramid -- left window
		glm::vec3(-0.25f, 4.0f, 5.125f),//bottom left
		glm::vec3(2.5f, 4.0f, 5.125f),//bottom right
		glm::vec3(2.5f, 4.0f, 4.875f),//top right
		glm::vec3(2.5f, 4.0f, 4.875f),//top right
		glm::vec3(-0.25f, 4.0f, 4.875f),//top left
		glm::vec3(-0.25f, 4.0f, 5.125f),//bottom left

		//little pyramid -- left window
		glm::vec3(0.5f, 4.0f, 5.5f),//bottom left
		glm::vec3(2.0f, 4.0f, 5.5f),//bottom right
		glm::vec3(2.0f, 4.0f, 5.125f),//top right
		glm::vec3(2.0f, 4.0f, 5.125f),//top right
		glm::vec3(0.5f, 4.0f, 5.125f),//top left
		glm::vec3(0.5f, 4.0f, 5.5f),//bottom left

		//big pyramid -- right window
		glm::vec3(4.5f, 4.0f, 5.125f),//bottom left
		glm::vec3(7.25f, 4.0f, 5.125f),//bottom right
		glm::vec3(7.25f, 4.0f, 4.875f),//top right
		glm::vec3(7.25f, 4.0f, 4.875f),//top right
		glm::vec3(4.5f, 4.0f, 4.875f),//top left
		glm::vec3(4.5f, 4.0f, 5.125f),//bottom left

		//little pyramid -- right window
		glm::vec3(5.0f, 4.0f, 5.5f),//bottom left
		glm::vec3(6.5f, 4.0f, 5.5f),//bottom right
		glm::vec3(6.5f, 4.0f, 5.125f),//top right
		glm::vec3(6.5f, 4.0f, 5.125f),//top right
		glm::vec3(5.0f, 4.0f, 5.125f),//top left
		glm::vec3(5.0f, 4.0f, 5.5f),//bottom left

		//FIRST FLOOR FLASHING
		glm::vec3(-0.25f, 2.0f, 6.0f),//bottom left
		glm::vec3(6.75f, 2.0f, 6.0f),//bottom right
		glm::vec3(6.75f, 2.0f, 5.0f),//top right
		glm::vec3(6.75f, 2.0f, 5.0f),//top right
		glm::vec3(-0.25f, 2.0f, 5.0f),//top left
		glm::vec3(-0.25f, 2.0f, 6.0f),//bottom left
		glm::vec3(6.75f, 2.0f, 6.25f),//bottom left
		glm::vec3(10.25f, 2.0f, 6.25f),//bottom right
		glm::vec3(10.25f, 2.0f, -0.25f),//top right
		glm::vec3(10.25f, 2.0f, -0.25f),//top right
		glm::vec3(6.75f, 2.0f, -0.25f),//top left
		glm::vec3(6.75f, 2.0f, 6.25f),//bottom left

		//PORCH PYRAMID FLASHING
		glm::vec3(2.0f, 2.125f, 6.25f),//bottom left
		glm::vec3(4.75f, 2.125f, 6.25f),//bottom right
		glm::vec3(4.75f, 2.125f, 2.5f),//top right
		glm::vec3(4.75f, 2.125f, 2.5f),//top right
		glm::vec3(2.0f, 2.125f, 2.5f),//top left
		glm::vec3(2.0f, 2.125f, 6.25f),//bottom left
	};
	porchCol.vertices = {
		//far left col
		//back cube face 
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left point
		glm::vec3(0.15f, 0.0f, 0.0f),//bottom right point
		glm::vec3(0.15f, 1.5f, 0.0f),//top right point
		glm::vec3(0.15f, 1.5f, 0.0f),//top right point
		glm::vec3(0.0f, 1.5f, 0.0f),//top left point
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left point

		//front cube face
		glm::vec3(0.0f, 0.0f, 0.15f),//bottom left point
		glm::vec3(0.15f, 0.0f, 0.15f),//bottom right point
		glm::vec3(0.15f, 1.5f, 0.15f),//top right point
		glm::vec3(0.15f, 1.5f, 0.15f),//top right point
		glm::vec3(0.0f, 1.5f, 0.15f),//top left point
		glm::vec3(0.0f, 0.0f, 0.15f),//bottom left point

		//left cube face
		glm::vec3(0.0f, 1.5f, 0.15f),//bottom left
		glm::vec3(0.0f, 1.5f, 0.0f),//bottom right
		glm::vec3(0.0f, 0.0f, 0.0f),//top right
		glm::vec3(0.0f, 0.0f, 0.0f),//top right
		glm::vec3(0.0f, 0.0f, 0.15f),//top left
		glm::vec3(0.0f, 1.5f, 0.15f),//bottom left

		//right cube face
		glm::vec3(0.15f, 1.5f, 0.15f),//bottom left
		glm::vec3(0.15f, 1.5f, 0.0f),//bottom right
		glm::vec3(0.15f, 0.0f, 0.0f),//top right
		glm::vec3(0.15f, 0.0f, 0.0f),//top right
		glm::vec3(0.15f, 0.0f, 0.15f),//top left
		glm::vec3(0.15f, 1.5f, 0.15f),//bottom left

		//small middle col
		//back cube face 
		glm::vec3(2.35f, 0.0f, 0.0f),//bottom left point
		glm::vec3(2.5f, 0.0f, 0.0f),//bottom right point
		glm::vec3(2.5f, 1.5f, 0.0f),//top right point
		glm::vec3(2.5f, 1.5f, 0.0f),//top right point
		glm::vec3(2.35f, 1.5f, 0.0f),//top left point
		glm::vec3(2.35f, 0.0f, 0.0f),//bottom left point

		//front cube face
		glm::vec3(2.35f, 0.0f, 0.15f),//bottom left point
		glm::vec3(2.5f, 0.0f, 0.15f),//bottom right point
		glm::vec3(2.5f, 1.5f, 0.15f),//top right point
		glm::vec3(2.5f, 1.5f, 0.15f),//top right point
		glm::vec3(2.35f, 1.5f, 0.15f),//top left point
		glm::vec3(2.35f, 0.0f, 0.15f),//bottom left point

		//left cube face
		glm::vec3(2.35f, 1.5f, 0.15f),//bottom left
		glm::vec3(2.35f, 1.5f, 0.0f),//bottom right
		glm::vec3(2.35f, 0.0f, 0.0f),//top right
		glm::vec3(2.35f, 0.0f, 0.0f),//top right
		glm::vec3(2.35f, 0.0f, 0.15f),//top left
		glm::vec3(2.35f, 1.5f, 0.15f),//bottom left

		//right cube face
		glm::vec3(2.5f, 1.5f, 0.15f),//bottom left
		glm::vec3(2.5f, 1.5f, 0.0f),//bottom right
		glm::vec3(2.5f, 0.0f, 0.0f),//top right
		glm::vec3(2.5f, 0.0f, 0.0f),//top right
		glm::vec3(2.5f, 0.0f, 0.15f),//top left
		glm::vec3(2.5f, 1.5f, 0.15f),//bottom left

		//small right col
		//back cube face 
		glm::vec3(4.0f, 0.0f, 0.0f),//bottom left point
		glm::vec3(4.15f, 0.0f, 0.0f),//bottom right point
		glm::vec3(4.15f, 1.5f, 0.0f),//top right point
		glm::vec3(4.15f, 1.5f, 0.0f),//top right point
		glm::vec3(4.0f, 1.5f, 0.0f),//top left point
		glm::vec3(4.0f, 0.0f, 0.0f),//bottom left point

		//front cube face
		glm::vec3(4.0f, 0.0f, 0.15f),//bottom left point
		glm::vec3(4.15f, 0.0f, 0.15f),//bottom right point
		glm::vec3(4.15f, 1.5f, 0.15f),//top right point
		glm::vec3(4.15f, 1.5f, 0.15f),//top right point
		glm::vec3(4.0f, 1.5f, 0.15f),//top left point
		glm::vec3(4.0f, 0.0f, 0.15f),//bottom left point

		//left cube face
		glm::vec3(4.0f, 1.5f, 0.15f),//bottom left
		glm::vec3(4.0f, 1.5f, 0.0f),//bottom right
		glm::vec3(4.0f, 0.0f, 0.0f),//top right
		glm::vec3(4.0f, 0.0f, 0.0f),//top right
		glm::vec3(4.0f, 0.0f, 0.15f),//top left
		glm::vec3(4.0f, 1.5f, 0.15f),//bottom left

		//right cube face
		glm::vec3(4.15f, 1.5f, 0.15f),//bottom left
		glm::vec3(4.15f, 1.5f, 0.0f),//bottom right
		glm::vec3(4.15f, 0.0f, 0.0f),//top right
		glm::vec3(4.15f, 0.0f, 0.0f),//top right
		glm::vec3(4.15f, 0.0f, 0.15f),//top left
		glm::vec3(4.15f, 1.5f, 0.15f),//bottom left

		//big left col
		//back cube face 1/4
		glm::vec3(2.35f, -0.5f, 0.33f),//bottom left point
		glm::vec3(2.5f, -0.5f, 0.33f),//bottom right point
		glm::vec3(2.5f, 0.0f, 0.33f),//top right point

		glm::vec3(2.5f, 0.0f, 0.33f),//top right point
		glm::vec3(2.35f, 0.0f, 0.33f),//top left point
		glm::vec3(2.35f, -0.5f, 0.33f),//bottom left point
		
		//2/4      
		glm::vec3(2.35f, 0.0f, 0.33f),//bottom left point
		glm::vec3(2.5f, 0.0f, 0.33f),//bottom right point
		glm::vec3(2.5f, 0.542f, 0.33f),//top right point
			
		glm::vec3(2.5f, 0.542f, 0.33f),//top right point
		glm::vec3(2.35f, 0.542f, 0.33f),//top left point
		glm::vec3(2.35f, 0.0f, 0.33f),//bottom left point

		//3/4
		glm::vec3(2.35f, 0.542f, 0.33f),//bottom left point
		glm::vec3(2.5f, 0.542f, 0.33f),//bottom right point
		glm::vec3(2.5f, 1.084f, 0.33f),//top right point

		glm::vec3(2.5f, 1.084f, 0.33f),//top right point
		glm::vec3(2.35f,1.084f, 0.33f),//top left point
		glm::vec3(2.35f, 0.542f, 0.33f),//bottom left point
		//4/4
		glm::vec3(2.35f, 1.084f, 0.33f),//bottom left point
		glm::vec3(2.5f, 1.084f, 0.33f),//bottom right point
		glm::vec3(2.5f, 1.625f, 0.33f),//top right point

		glm::vec3(2.5f, 1.625f, 0.33f),//top right point
		glm::vec3(2.35f, 1.625f, 0.33f),//top left point
		glm::vec3(2.35f, 1.084f, 0.33f),//bottom left point

		//front cube face
		glm::vec3(2.35f, -0.5f, 0.48f),//bottom left point
		glm::vec3(2.5f, -0.5f, 0.48f),//bottom right point
		glm::vec3(2.5f, 0.0f, 0.48f),//top right point

		glm::vec3(2.5f, 0.0f, 0.48f),//top right point
		glm::vec3(2.35f, 0.0f, 0.48f),//top left point
		glm::vec3(2.35f, -0.5f, 0.48f),//bottom left point

		//2/4      
		glm::vec3(2.35f, 0.0f, 0.48f),//bottom left point
		glm::vec3(2.5f, 0.0f, 0.48f),//bottom right point
		glm::vec3(2.5f, 0.542f, 0.48f),//top right point

		glm::vec3(2.5f, 0.542f, 0.48f),//top right point
		glm::vec3(2.35f, 0.542f, 0.48f),//top left point
		glm::vec3(2.35f, 0.0f, 0.48f),//bottom left point

		//3/4
		glm::vec3(2.35f, 0.542f, 0.48f),//bottom left point
		glm::vec3(2.5f, 0.542f, 0.48f),//bottom right point
		glm::vec3(2.5f, 1.084f, 0.48f),//top right point

		glm::vec3(2.5f, 1.084f, 0.48f),//top right point
		glm::vec3(2.35f, 1.084f, 0.48f),//top left point
		glm::vec3(2.35f, 0.542f, 0.48f),//bottom left point
		//4/4
		glm::vec3(2.35f, 1.084f, 0.48f),//bottom left point
		glm::vec3(2.5f, 1.084f, 0.48f),//bottom right point
		glm::vec3(2.5f, 1.625f, 0.48f),//top right point

		glm::vec3(2.5f, 1.625f, 0.48f),//top right point
		glm::vec3(2.35f, 1.625f, 0.48f),//top left point
		glm::vec3(2.35f, 1.084f, 0.48f),//bottom left point

		
		//left cube face
		glm::vec3(2.35f, -0.5f, 0.48f),//bottom left point
		glm::vec3(2.35f, -0.5f, 0.33f),//bottom right point
		glm::vec3(2.35f, 0.0f, 0.33f),//bottom right point

		glm::vec3(2.35f, 0.0f, 0.33f),//bottom right point
		glm::vec3(2.35f, 0.0f, 0.48f),//top left point
		glm::vec3(2.35f, -0.5f, 0.48f),//bottom left point

		//2/4      
		glm::vec3(2.35f, 0.0f, 0.48f),//bottom left point
		glm::vec3(2.35f, 0.0f, 0.33f),//bottom right point
		glm::vec3(2.35f, 0.542f, 0.33f),//bottom right point

		glm::vec3(2.35f, 0.542f, 0.33f),//bottom right point
		glm::vec3(2.35f, 0.542f, 0.48f),//top left point
		glm::vec3(2.35f, 0.0f, 0.48f),//bottom left point

		//3/4
		glm::vec3(2.35f, 0.542f, 0.48f),//bottom left point
		glm::vec3(2.35f, 0.542f, 0.33f),//bottom right point
		glm::vec3(2.35f, 1.084f, 0.33f),//bottom right point

		glm::vec3(2.35f, 1.084f, 0.33f),//bottom right point
		glm::vec3(2.35f, 1.084f, 0.48f),//top left point
		glm::vec3(2.35f, 0.542f, 0.48f),//bottom left point
		//4/4
		glm::vec3(2.35f, 1.084f, 0.48f),//bottom left point
		glm::vec3(2.35f, 1.084f, 0.33f),//bottom right point
		glm::vec3(2.35f, 1.625f, 0.33f),//bottom right point

		glm::vec3(2.35f, 1.625f, 0.33f),//bottom right point
		glm::vec3(2.35f, 1.625f, 0.48f),//top left point
		glm::vec3(2.35f, 1.084f, 0.48f),//bottom left point

		//right cube face
		glm::vec3(2.5f, -0.5f, 0.48f),//bottom left point
		glm::vec3(2.5f, -0.5f, 0.33f),//bottom right point
		glm::vec3(2.5f, 0.0f, 0.33f),//bottom right point

		glm::vec3(2.5f, 0.0f, 0.33f),//bottom right point
		glm::vec3(2.5f, 0.0f, 0.48f),//top left point
		glm::vec3(2.5f, -0.5f, 0.48f),//bottom left point

		//2/4      
		glm::vec3(2.5f, 0.0f, 0.48f),//bottom left point
		glm::vec3(2.5f, 0.0f, 0.33f),//bottom right point
		glm::vec3(2.5f, 0.542f, 0.33f),//bottom right point

		glm::vec3(2.5f, 0.542f, 0.33f),//bottom right point
		glm::vec3(2.5f, 0.542f, 0.48f),//top left point
		glm::vec3(2.5f, 0.0f, 0.48f),//bottom left point

		//3/4
		glm::vec3(2.5f, 0.542f, 0.48f),//bottom left point
		glm::vec3(2.5f, 0.542f, 0.33f),//bottom right point
		glm::vec3(2.5f, 1.084f, 0.33f),//bottom right point

		glm::vec3(2.5f, 1.084f, 0.33f),//bottom right point
		glm::vec3(2.5f, 1.084f, 0.48f),//top left point
		glm::vec3(2.5f, 0.542f, 0.48f),//bottom left point
		//4/4
		glm::vec3(2.5f, 1.084f, 0.48f),//bottom left point
		glm::vec3(2.5f, 1.084f, 0.33f),//bottom right point
		glm::vec3(2.5f, 1.625f, 0.33f),//bottom right point

		glm::vec3(2.5f, 1.625f, 0.33f),//bottom right point
		glm::vec3(2.5f, 1.625f, 0.48f),//top left point
		glm::vec3(2.5f, 1.084f, 0.48f),//bottom left point

		//big right col
		//back cube face 1/4
		glm::vec3(4.0f, -0.5f, 0.33f),//bottom left point
		glm::vec3(4.15f, -0.5f, 0.33f),//bottom right point
		glm::vec3(4.15f, 0.0f, 0.33f),//top right point

		glm::vec3(4.15f, 0.0f, 0.33f),//top right point
		glm::vec3(4.0f, 0.0f, 0.33f),//top left point
		glm::vec3(4.0f, -0.5f, 0.33f),//bottom left point

		//2/4      
		glm::vec3(4.0f, 0.0f, 0.33f),//bottom left point
		glm::vec3(4.15f, 0.0f, 0.33f),//bottom right point
		glm::vec3(4.15f, 0.542f, 0.33f),//top right point

		glm::vec3(4.15f, 0.542f, 0.33f),//top right point
		glm::vec3(4.0f, 0.542f, 0.33f),//top left point
		glm::vec3(4.0f, 0.0f, 0.33f),//bottom left point

		//3/4
		glm::vec3(4.0f, 0.542f, 0.33f),//bottom left point
		glm::vec3(4.15f, 0.542f, 0.33f),//bottom right point
		glm::vec3(4.15f, 1.084f, 0.33f),//top right point

		glm::vec3(4.15f, 1.084f, 0.33f),//top right point
		glm::vec3(4.0f, 1.084f, 0.33f),//top left point
		glm::vec3(4.0f, 0.542f, 0.33f),//bottom left point
		//4/4
		glm::vec3(4.0f, 1.084f, 0.33f),//bottom left point
		glm::vec3(4.15f, 1.084f, 0.33f),//bottom right point
		glm::vec3(4.15f, 1.625f, 0.33f),//top right point

		glm::vec3(4.15f, 1.625f, 0.33f),//top right point
		glm::vec3(4.0f, 1.625f, 0.33f),//top left point
		glm::vec3(4.0f, 1.084f, 0.33f),//bottom left point

		//front cube face
		glm::vec3(4.0f, -0.5f, 0.48f),//bottom left point
		glm::vec3(4.15f, -0.5f, 0.48f),//bottom right point
		glm::vec3(4.15f, 0.0f, 0.48f),//top right point

		glm::vec3(4.15f, 0.0f, 0.48f),//top right point
		glm::vec3(4.0f, 0.0f, 0.48f),//top left point
		glm::vec3(4.0f, -0.5f, 0.48f),//bottom left point

		//2/4      
		glm::vec3(4.0f, 0.0f, 0.48f),//bottom left point
		glm::vec3(4.15f, 0.0f, 0.48f),//bottom right point
		glm::vec3(4.15f, 0.542f, 0.48f),//top right point

		glm::vec3(4.15f, 0.542f, 0.48f),//top right point
		glm::vec3(4.0f, 0.542f, 0.48f),//top left point
		glm::vec3(4.0f, 0.0f, 0.48f),//bottom left point

		//3/4
		glm::vec3(4.0f, 0.542f, 0.48f),//bottom left point
		glm::vec3(4.15f, 0.542f, 0.48f),//bottom right point
		glm::vec3(4.15f, 1.084f, 0.48f),//top right point

		glm::vec3(4.15f, 1.084f, 0.48f),//top right point
		glm::vec3(4.0f, 1.084f, 0.48f),//top left point
		glm::vec3(4.0f, 0.542f, 0.48f),//bottom left point
		//4/4
		glm::vec3(4.0f, 1.084f, 0.48f),//bottom left point
		glm::vec3(4.15f, 1.084f, 0.48f),//bottom right point
		glm::vec3(4.15f, 1.625f, 0.48f),//top right point

		glm::vec3(4.15f, 1.625f, 0.48f),//top right point
		glm::vec3(4.0f, 1.625f, 0.48f),//top left point
		glm::vec3(4.0f, 1.084f, 0.48f),//bottom left point


		//left cube face
		glm::vec3(4.0f, -0.5f, 0.48f),//bottom left point
		glm::vec3(4.0f, -0.5f, 0.33f),//bottom right point
		glm::vec3(4.0f, 0.0f, 0.33f),//bottom right point

		glm::vec3(4.0f, 0.0f, 0.33f),//bottom right point
		glm::vec3(4.0f, 0.0f, 0.48f),//top left point
		glm::vec3(4.0f, -0.5f, 0.48f),//bottom left point

		//2/4      
		glm::vec3(4.0f, 0.0f, 0.48f),//bottom left point
		glm::vec3(4.0f, 0.0f, 0.33f),//bottom right point
		glm::vec3(4.0f, 0.542f, 0.33f),//bottom right point

		glm::vec3(4.0f, 0.542f, 0.33f),//bottom right point
		glm::vec3(4.0f, 0.542f, 0.48f),//top left point
		glm::vec3(4.0f, 0.0f, 0.48f),//bottom left point

		//3/4
		glm::vec3(4.0f, 0.542f, 0.48f),//bottom left point
		glm::vec3(4.0f, 0.542f, 0.33f),//bottom right point
		glm::vec3(4.0f, 1.084f, 0.33f),//bottom right point

		glm::vec3(4.0f, 1.084f, 0.33f),//bottom right point
		glm::vec3(4.0f, 1.084f, 0.48f),//top left point
		glm::vec3(4.0f, 0.542f, 0.48f),//bottom left point
		//4/4
		glm::vec3(4.0f, 1.084f, 0.48f),//bottom left point
		glm::vec3(4.0f, 1.084f, 0.33f),//bottom right point
		glm::vec3(4.0f, 1.625f, 0.33f),//bottom right point

		glm::vec3(4.0f, 1.625f, 0.33f),//bottom right point
		glm::vec3(4.0f, 1.625f, 0.48f),//top left point
		glm::vec3(4.0f, 1.084f, 0.48f),//bottom left point

		//right cube face
		glm::vec3(4.15f, -0.5f, 0.48f),//bottom left point
		glm::vec3(4.15f, -0.5f, 0.33f),//bottom right point
		glm::vec3(4.15f, 0.0f, 0.33f),//bottom right point

		glm::vec3(4.15f, 0.0f, 0.33f),//bottom right point
		glm::vec3(4.15f, 0.0f, 0.48f),//top left point
		glm::vec3(4.15f, -0.5f, 0.48f),//bottom left point

		//2/4      
		glm::vec3(4.15f, 0.0f, 0.48f),//bottom left point
		glm::vec3(4.15f, 0.0f, 0.33f),//bottom right point
		glm::vec3(4.15f, 0.542f, 0.33f),//bottom right point

		glm::vec3(4.15f, 0.542f, 0.33f),//bottom right point
		glm::vec3(4.15f, 0.542f, 0.48f),//top left point
		glm::vec3(4.15f, 0.0f, 0.48f),//bottom left point

		//3/4
		glm::vec3(4.15f, 0.542f, 0.48f),//bottom left point
		glm::vec3(4.15f, 0.542f, 0.33f),//bottom right point
		glm::vec3(4.15f, 1.084f, 0.33f),//bottom right point

		glm::vec3(4.15f, 1.084f, 0.33f),//bottom right point
		glm::vec3(4.15f, 1.084f, 0.48f),//top left point
		glm::vec3(4.15f, 0.542f, 0.48f),//bottom left point
		//4/4
		glm::vec3(4.15f, 1.084f, 0.48f),//bottom left point
		glm::vec3(4.15f, 1.084f, 0.33f),//bottom right point
		glm::vec3(4.15f, 1.625f, 0.33f),//bottom right point

		glm::vec3(4.15f, 1.625f, 0.33f),//bottom right point
		glm::vec3(4.15f, 1.625f, 0.48f),//top left point
		glm::vec3(4.15f, 1.084f, 0.48f),//bottom left point
	};
	smallCol.vertices = {//back cube face 
		glm::vec3(-0.15f, -1.0f, -0.15f),//bottom left point
		glm::vec3(0.15f, -1.0f, -0.15f),//bottom right point
		glm::vec3(0.15f, 1.0f, -0.15f),//top right point
		glm::vec3(0.15f, 1.0f, -0.15f),//top right point
		glm::vec3(-0.15f, 1.0f, -0.15f),//top left point
		glm::vec3(-0.15f, -1.0f, -0.15f),//bottom left point

		//front cube face
		glm::vec3(-0.15f, -1.0f, 0.15f),//bottom left point
		glm::vec3(0.15f, -1.0f, 0.15f),//bottom right point
		glm::vec3(0.15f, 1.0f, 0.15f),//top right point
		glm::vec3(0.15f, 1.0f, 0.15f),//top right point
		glm::vec3(-0.15f, 1.0f, 0.15f),//top left point
		glm::vec3(-0.15f, -1.0f, 0.15f),//bottom left point

		//left cube face
		glm::vec3(-0.15f, 1.0f, 0.15f),//bottom left
		glm::vec3(-0.15f, 1.0f, -0.15f),//bottom right
		glm::vec3(-0.15f, -1.0f, -0.15f),//top right
		glm::vec3(-0.15f, -1.0f, -0.15f),//top right
		glm::vec3(-0.15f, -1.0f, 0.15f),//top left
		glm::vec3(-0.15f, 1.0f, 0.15f),//bottom left

		//right cube face
		glm::vec3(0.15f, 1.0f, 0.15f),//bottom left
		glm::vec3(0.15f, 1.0f, -0.15f),//bottom right
		glm::vec3(0.15f, -1.0f, -0.15f),//top right
		glm::vec3(0.15f, -1.0f, -0.15f),//top right
		glm::vec3(0.15f, -1.0f, 0.15f),//top left
		glm::vec3(0.15f, 1.0f, 0.15f),//bottom left

		//bottom cube face
		glm::vec3(-0.15f, -1.0f, -0.15f),//bottom left
		glm::vec3(0.15f, -1.0f, -0.15f),//bottom right
		glm::vec3(0.15f, -1.0f, 0.15f),//top right
		glm::vec3(0.15f, -1.0f, 0.15f),//top right
		glm::vec3(-0.15f, -1.0f, 0.15f),//top left
		glm::vec3(-0.15f, -1.0f, -0.15f),//bottom left

		//top cube face
		glm::vec3(-0.15f, 1.0f, -0.15f),//bottom left
		glm::vec3(0.15f, 1.0f, -0.15f),//bottom right
		glm::vec3(0.15f, 1.0f, 0.15f),//top right
		glm::vec3(0.15f, 1.0f, 0.15f),//top right
		glm::vec3(-0.15f, 1.0f, 0.15f),//top left
		glm::vec3(-0.15f, 1.0f, -0.15f),//bottom left
	}; //NOT NEEDED
	frontStairs.vertices = {
		//Garden box needs to be .3 tall, 6 long, 1.2 in depth
		//stairs are 1.5 long, .1 tall, .1 in depth
		//back face 
		glm::vec3(-0.75f, 0.0f, 0.0f),//bottom left point
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom right point
		glm::vec3(0.0f, 0.2f, 0.0f),//top right point
		glm::vec3(0.0f, 0.2f, 0.0f),//top right point
		glm::vec3(-0.75f, 0.2f, 0.0f),//top left point
		glm::vec3(-0.75f, 0.0f, 0.0f),//bottom left point

		//left face
		glm::vec3(-0.75f, 0.0f, 0.0f),//bottom left point
		glm::vec3(-0.75f, 0.0f, 1.05f),//bottom right point
		glm::vec3(-0.75f, 0.2f, 1.05f),//top right point
		glm::vec3(-0.75f, 0.2f, 1.05f),//top right point
		glm::vec3(-0.75f, 0.2f, 0.0f),//top left point
		glm::vec3(-0.75f, 0.0f, 0.0f),//bottom left point

		//front face
		glm::vec3(-0.75f, 0.0f, 1.05f),//bottom left point
		glm::vec3(5.0f, 0.0f, 1.05f),//bottom right point
		glm::vec3(5.0f, 0.2f, 1.05f),//top right point
		glm::vec3(5.0f, 0.2f, 1.05f),//top right point
		glm::vec3(-0.75f, 0.2f, 1.05f),//top left point
		glm::vec3(-0.75f, 0.0f, 1.05f),//bottom left point

		//right cube face
		glm::vec3(5.0f, 0.0f, 1.05f),//bottom left point
		glm::vec3(5.0f, 0.0f, 0.75f),//bottom right point
		glm::vec3(5.0f, 0.2f, 0.75f),//top right point
		glm::vec3(5.0f, 0.2f, 0.75f),//top right point
		glm::vec3(5.0f, 0.2f, 1.05f),//top left point
		glm::vec3(5.0f, 0.0f, 1.05f),//bottom left point

		//stairs start here. x value of 2
		//first stair flat
		glm::vec3(2.5f, 0.4f, 0.85f),//bottom left point
		glm::vec3(4.0f, 0.4f, 0.85f),//bottom right point
		glm::vec3(4.0f, 0.4f, 0.75f),//top right point
		glm::vec3(4.0f, 0.4f, 0.75f),//top right point
		glm::vec3(2.5f, 0.4f, 0.75f),//top left point
		glm::vec3(2.5f, 0.4f, 0.85f),//bottom left point

		//second stair flat
		glm::vec3(2.5f, 0.3f, 0.95f),//bottom left point
		glm::vec3(4.0f, 0.3f, 0.95f),//bottom right point
		glm::vec3(4.0f, 0.3f, 0.85f),//top right point
		glm::vec3(4.0f, 0.3f, 0.85f),//top right point
		glm::vec3(2.5f, 0.3f, 0.85f),//top left point
		glm::vec3(2.5f, 0.3f, 0.95f),//bottom left point

		//third stair flat
		glm::vec3(2.5f, 0.2f, 1.05f),//bottom left point
		glm::vec3(4.0f, 0.2f, 1.05f),//bottom right point
		glm::vec3(4.0f, 0.2f, 0.95f),//top right point
		glm::vec3(4.0f, 0.2f, 0.95f),//top right point
		glm::vec3(2.5f, 0.2f, 0.95f),//top left point
		glm::vec3(2.5f, 0.2f, 1.05f),//bottom left point

		//first stair wall
		glm::vec3(2.5f, 0.3f, 0.85f),//bottom left point
		glm::vec3(4.0f, 0.3f, 0.85f),//bottom right point
		glm::vec3(4.0f, 0.4f, 0.85f),//top right point
		glm::vec3(4.0f, 0.4f, 0.85f),//top right point
		glm::vec3(2.5f, 0.4f, 0.85f),//top left point
		glm::vec3(2.5f, 0.3f, 0.85f),//bottom left point

		//second stair wall
		glm::vec3(2.5f, 0.2f, 0.95f),//bottom left point
		glm::vec3(4.0f, 0.2f, 0.95f),//bottom right point
		glm::vec3(4.0f, 0.3f, 0.95f),//top right point
		glm::vec3(4.0f, 0.3f, 0.95f),//top right point
		glm::vec3(2.5f, 0.3f, 0.95f),//top left point
		glm::vec3(2.5f, 0.2f, 0.95f),//bottom left point

		//left stair sidewall
		//top stair
		glm::vec3(2.5f, 0.3f, 0.75f),//bottom left point
		glm::vec3(2.5f, 0.3f, 0.85f),//bottom right point
		glm::vec3(2.5f, 0.4f, 0.85f),//top right point
		glm::vec3(2.5f, 0.4f, 0.85f),//top right point
		glm::vec3(2.5f, 0.4f, 0.75f),//top left point
		glm::vec3(2.5f, 0.3f, 0.75f),//bottom left point

		//second stair
		glm::vec3(2.5f, 0.2f, 0.75f),//bottom left point
		glm::vec3(2.5f, 0.2f, 0.95f),//bottom right point
		glm::vec3(2.5f, 0.3f, 0.95f),//top right point
		glm::vec3(2.5f, 0.3f, 0.95f),//top right point
		glm::vec3(2.5f, 0.3f, 0.75f),//top left point
		glm::vec3(2.5f, 0.2f, 0.75f),//bottom left point

		//third stair
		glm::vec3(2.5f, 0.1f, 0.75f),//bottom left point
		glm::vec3(2.5f, 0.1f, 1.05f),//bottom right point
		glm::vec3(2.5f, 0.2f, 1.05f),//top right point
		glm::vec3(2.5f, 0.2f, 1.05f),//top right point
		glm::vec3(2.5f, 0.2f, 0.75f),//top left point
		glm::vec3(2.5f, 0.1f, 0.75f),//bottom left point

		//right stair sidewall
		//top stair
		glm::vec3(4.0f, 0.3f, 0.75f),//bottom left point
		glm::vec3(4.0f, 0.3f, 0.85f),//bottom right point
		glm::vec3(4.0f, 0.4f, 0.85f),//top right point
		glm::vec3(4.0f, 0.4f, 0.85f),//top right point
		glm::vec3(4.0f, 0.4f, 0.75f),//top left point
		glm::vec3(4.0f, 0.3f, 0.75f),//bottom left point

		//second stair
		glm::vec3(4.0f, 0.2f, 0.75f),//bottom left point
		glm::vec3(4.0f, 0.2f, 0.95f),//bottom right point
		glm::vec3(4.0f, 0.3f, 0.95f),//top right point
		glm::vec3(4.0f, 0.3f, 0.95f),//top right point
		glm::vec3(4.0f, 0.3f, 0.75f),//top left point
		glm::vec3(4.0f, 0.2f, 0.75f),//bottom left point

		//third stair
		glm::vec3(4.0f, 0.1f, 0.75f),//bottom left point
		glm::vec3(4.0f, 0.1f, 1.05f),//bottom right point
		glm::vec3(4.0f, 0.2f, 1.05f),//top right point
		glm::vec3(4.0f, 0.2f, 1.05f),//top right point
		glm::vec3(4.0f, 0.2f, 0.75f),//top left point
		glm::vec3(4.0f, 0.1f, 0.75f),//bottom left point

		//pad - top
		glm::vec3(2.5f, 0.1f, 1.445f),//bottom left point
		glm::vec3(4.0f, 0.1f, 1.445f),//bottom right point
		glm::vec3(4.0f, 0.1f, 1.05f),//top right point
		glm::vec3(4.0f, 0.1f, 1.05f),//top right point
		glm::vec3(2.5f, 0.1f, 1.05f),//top left point
		glm::vec3(2.5f, 0.1f, 1.445f),//bottom left point

		//pad - front wall
		glm::vec3(2.5f, 0.0f, 1.445f),//bottom left point
		glm::vec3(4.0f, 0.0f, 1.445f),//bottom right point
		glm::vec3(4.0f, 0.1f, 1.445f),//top right point
		glm::vec3(4.0f, 0.1f, 1.445f),//top right point
		glm::vec3(2.5f, 0.1f, 1.445f),//top left point
		glm::vec3(2.5f, 0.0f, 1.445f),//bottom left point

		//pad - front wall
		glm::vec3(4.0f, 0.0f, 1.445f),//bottom left point
		glm::vec3(4.0f, 0.0f, 1.05f),//bottom right point
		glm::vec3(4.0f, 0.1f, 1.05f),//top right point
		glm::vec3(4.0f, 0.1f, 1.05f),//top right point
		glm::vec3(4.0f, 0.1f, 1.445f),//top left point
		glm::vec3(4.0f, 0.0f, 1.445f),//bottom left point

		//pad - left wall
		glm::vec3(2.5f, 0.0f, 1.445f),//bottom left point
		glm::vec3(2.5f, 0.0f, 1.05f),//bottom right point
		glm::vec3(2.5f, 0.1f, 1.05f),//top right point
		glm::vec3(2.5f, 0.1f, 1.05f),//top right point
		glm::vec3(2.5f, 0.1f, 1.445f),//top left point
		glm::vec3(2.5f, 0.0f, 1.445f),//bottom left point

		//single stair
		glm::vec3(4.0f, 0.01f, 1.445f),//bottom left point
		glm::vec3(4.15f, 0.01f, 1.445f),//bottom right point
		glm::vec3(4.15f, 0.01f, 1.05f),//top right point
		glm::vec3(4.15f, 0.01f, 1.05f),//top right point
		glm::vec3(4.0f, 0.01f, 1.05f),//top left point
		glm::vec3(4.0f, 0.01f, 1.445f),//bottom left point
	};
	mulch.vertices = {
		//front cube face
		glm::vec3(0.0f, 0.0f, -0.05f),//bottom left point
		glm::vec3(5.75f, 0.0f, -0.05f),//bottom right point
		glm::vec3(5.75f, 0.0f, 0.999f),//top right point
		glm::vec3(5.75f, 0.0f, 0.999f),//top right point
		glm::vec3(0.0f, 0.0f, 0.999f),//top left point
		glm::vec3(0.0f, 0.0f, -0.05f),//bottom left point
	};
	garage.vertices = {
		//single
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left point
		glm::vec3(1.5f, 0.0f, 0.0f),//bottom right point
		glm::vec3(1.5f, 1.25f, 0.0f),//top right point
		glm::vec3(1.5f, 1.25f, 0.0f),//top right point
		glm::vec3(0.0f, 1.25f, 0.0f),//top left point
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left point

		//double
		glm::vec3(2.0f, 0.0f, 0.25f),//bottom left point
		glm::vec3(4.5f, 0.0f, 0.25f),//bottom right point
		glm::vec3(4.5f, 1.25f, 0.25f),//top right point
		glm::vec3(4.5f, 1.25f, 0.25f),//top right point
		glm::vec3(2.0f, 1.25f, 0.25f),//top left point
		glm::vec3(2.0f, 0.0f, 0.25f),//bottom left point
	};
	porchPyramid.vertices = {
		//front face -- left window
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left point
		glm::vec3(2.75f, 0.0f, 0.0f),//bottom right point
		glm::vec3(1.51f, 0.548f, -0.75f),//top right point (middle)

		//left face -- left window
		glm::vec3(0.0f, 0.0f, -2.5f),//bottom left
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom right
		glm::vec3(1.51f, 0.548f, -0.75f),//top right point
		glm::vec3(1.51f, 0.548f, -0.75f),//top right point
		glm::vec3(1.51f, 0.548f, -2.5f),//top left point
		glm::vec3(0.0f, 0.0f, -2.5f),//bottom left point

		//right face -- left window
		glm::vec3(2.75f, 0.0f, 0.0f),//bottom left
		glm::vec3(2.75f, 0.0f, -2.5f),//bottom right
		glm::vec3(1.51f, 0.548f, -2.5f),//top right point
		glm::vec3(1.51f, 0.548f, -2.5f),//top right point
		glm::vec3(1.51f, 0.548f, -0.75f),//top left point
		glm::vec3(2.75f, 0.0f, 0.0f),//bottom left point
	};
	garagePyramid.vertices = {
		//front face -- left window
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left point
		glm::vec3(3.5f, 0.0f, 0.0f),//bottom right point
		glm::vec3(1.75f, 1.075f, -1.0f),//top right point (middle)

		//left face -- left window
		glm::vec3(0.0f, 0.0f, -2.5f),//bottom left
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom right
		glm::vec3(1.75f, 1.075f, -1.0f),//top right point
		glm::vec3(1.75f, 1.075f, -1.0f),//top right point
		glm::vec3(1.75f, 1.075f, -2.5f),//top left point
		glm::vec3(0.0f, 0.0f, -2.5f),//bottom left point

		//right face -- left window
		glm::vec3(3.5f, 0.0f, 0.0f),//bottom left
		glm::vec3(3.5f, 0.0f, -2.5f),//bottom right
		glm::vec3(1.75f, 1.075f, -2.5f),//top right point
		glm::vec3(1.75f, 1.075f, -2.5f),//top right point
		glm::vec3(1.75f, 1.075f, -1.0f),//top left point
		glm::vec3(3.5f, 0.0f, 0.0f),//bottom left point
	};
	porchFence.vertices = {
		//left face
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left point
		glm::vec3(0.0f, 0.0f, 0.65f),//bottom right point
		glm::vec3(0.0f, 0.5f, 0.65f),//top right point
		glm::vec3(0.0f, 0.5f, 0.65f),//top right point
		glm::vec3(0.0f, 0.5f, 0.0f),//top left point
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left point

		//front face left
		glm::vec3(0.0f, 0.0f, 0.65f),//bottom left point
		glm::vec3(2.35f, 0.0f, 0.65f),//bottom right point
		glm::vec3(2.35f, 0.5f, 0.65f),//top right point
		glm::vec3(2.35f, 0.5f, 0.65f),//top right point
		glm::vec3(0.0f, 0.5f, 0.65f),//top left point
		glm::vec3(0.0f, 0.0f, 0.65f),//bottom left point

		//front face right
		glm::vec3(4.05f, 0.0f, 0.65f),//bottom left point
		glm::vec3(5.0f, 0.0f, 0.65f),//bottom right point
		glm::vec3(5.0f, 0.5f, 0.65f),//top right point
		glm::vec3(5.0f, 0.5f, 0.65f),//top right point
		glm::vec3(4.05f, 0.5f, 0.65f),//top left point
		glm::vec3(4.05f, 0.0f, 0.65f),//bottom left point

		//stairs left
		glm::vec3(2.47f, 0.0f, 0.65f),//bottom left point
		glm::vec3(2.47f, -0.5f, 1.057f),//bottom right point
		glm::vec3(2.47f, 0.0f, 1.057f),//top right point
		glm::vec3(2.47f, 0.0f, 1.057f),//top right point
		glm::vec3(2.47f, 0.5f, 0.65f),//top left point
		glm::vec3(2.47f, 0.0f, 0.65f),//bottom left point

		glm::vec3(2.47f, -0.5f, 1.057f),//bottom left point
		glm::vec3(2.47f, -0.5f, 1.43f),//bottom right point
		glm::vec3(2.47f, 0.0f, 1.43f),//top right point
		glm::vec3(2.47f, 0.0f, 1.43f),//top right point
		glm::vec3(2.47f, 0.0f, 1.057f),//top left point
		glm::vec3(2.47f, -0.5f, 1.057f),//bottom left point

		//stairs right
		glm::vec3(3.94f, 0.0f, 0.65f),//bottom left point
		glm::vec3(3.94f, -0.5f, 1.057f),//bottom right point
		glm::vec3(3.94f, 0.0f, 1.057f),//top right point
		glm::vec3(3.94f, 0.0f, 1.057f),//top right point
		glm::vec3(3.94f, 0.5f, 0.65f),//top left point
		glm::vec3(3.94f, 0.0f, 0.65f),//bottom left point

		//front face forward
		glm::vec3(2.47f, -0.5f, 1.43f),//bottom left point
		glm::vec3(3.94f, -0.5f, 1.43f),//bottom right point
		glm::vec3(3.94f, 0.0f, 1.43f),//top right point
		glm::vec3(3.94f, 0.0f, 1.43f),//top right point
		glm::vec3(2.47f, 0.0f, 1.43f),//top left point
		glm::vec3(2.47f, -0.5f, 1.43f),//bottom left point
	};
	windowsLR.vertices = {
		//FRONT PORCH OUTLET
		//left outlet face
		glm::vec3(0.378f, 0.75f, 5.035f),//bottom left point
		glm::vec3(0.73f, 0.75f, 5.356f),//bottom right point
		glm::vec3(0.73f, 1.8f, 5.356f),//top right point
		glm::vec3(0.73f, 1.8f, 5.356f),//top right point
		glm::vec3(0.378f, 1.8f, 5.035f),//top left point
		glm::vec3(0.378f, 0.75f, 5.035f),//bottom left point

		//front outlet face
		glm::vec3(0.85f, 0.75f, 5.3755f),//bottom left point
		glm::vec3(1.65f, 0.75f, 5.3755f),//bottom right point
		glm::vec3(1.65f, 1.8f, 5.3755f),//top right point
		glm::vec3(1.65f, 1.8f, 5.3755f),//top right point
		glm::vec3(0.85f, 1.8f, 5.3755f),//top left point
		glm::vec3(0.85f, 0.75f, 5.3755f),//bottom left point

		//right outlet face
		glm::vec3(1.8f, 0.75f, 5.355f),//bottom left
		glm::vec3(2.1f, 0.75f, 5.05f),//bottom right
		glm::vec3(2.1f, 1.8f, 5.05f),//top right
		glm::vec3(2.1f, 1.8f, 5.05f),//top right
		glm::vec3(1.8f, 1.8f, 5.355f),//top left
		glm::vec3(1.8f, 0.75f, 5.355f),//bottom left

		//front top left
		glm::vec3(0.85f, 2.75f, 5.3755f),//bottom left point
		glm::vec3(1.65f, 2.75f, 5.3755f),//bottom right point
		glm::vec3(1.65f, 3.75f, 5.3755f),//top right point
		glm::vec3(1.65f, 3.75f, 5.3755f),//top right point
		glm::vec3(0.85f, 3.75f, 5.3755f),//top left point
		glm::vec3(0.85f, 2.75f, 5.3755f),//bottom left point

		//front top right
		glm::vec3(5.35f, 2.75f, 5.3755f),//bottom left point
		glm::vec3(6.15f, 2.75f, 5.3755f),//bottom right point
		glm::vec3(6.15f, 3.75f, 5.3755f),//top right point
		glm::vec3(6.15f, 3.75f, 5.3755f),//top right point
		glm::vec3(5.35f, 3.75f, 5.3755f),//top left point
		glm::vec3(5.35f, 2.75f, 5.3755f),//bottom left point

		//left face left 
		glm::vec3(-0.02f, 0.75f, 1.2f),//bottom left point
		glm::vec3(-0.02f, 0.75f, 2.2f),//bottom right point
		glm::vec3(-0.02f, 1.8f, 2.2f),//top right point
		glm::vec3(-0.02f, 1.8f, 2.2f),//top right point
		glm::vec3(-0.02f, 1.8f, 1.2f),//top left point
		glm::vec3(-0.02f, 0.75f, 1.2f),//bottom left point

		//far right top back face
		glm::vec3(0.1f, 3.15f, -0.255f),//bottom left point
		glm::vec3(0.9f, 3.15f, -0.255f),//bottom right point
		glm::vec3(0.9f, 3.9f, -0.255f),//top right point
		glm::vec3(0.9f, 3.9f, -0.255f),//top right point
		glm::vec3(0.1f, 3.9f, -0.255f),//top left point
		glm::vec3(0.1f, 3.15f, -0.255f),//bottom left point

		//middle top back face
		glm::vec3(2.1f, 3.0f, -0.255f),//bottom left point
		glm::vec3(2.8f, 3.0f, -0.255f),//bottom right point
		glm::vec3(2.8f, 3.9f, -0.255f),//top right point
		glm::vec3(2.8f, 3.9f, -0.255f),//top right point
		glm::vec3(2.1f, 3.9f, -0.255f),//top left point
		glm::vec3(2.1f, 3.0f, -0.255f),//bottom left point

		//left top back face
		glm::vec3(5.1f, 3.0f, -0.255f),//bottom left point
		glm::vec3(5.8f, 3.0f, -0.255f),//bottom right point
		glm::vec3(5.8f, 3.9f, -0.255f),//top right point
		glm::vec3(5.8f, 3.9f, -0.255f),//top right point
		glm::vec3(5.1f, 3.9f, -0.255f),//top left point
		glm::vec3(5.1f, 3.0f, -0.255f),//bottom left point

		//left bottom back face
		glm::vec3(7.0f, 0.75f, -0.001f),//bottom left point
		glm::vec3(8.0f, 0.75f, -0.001f),//bottom right point
		glm::vec3(8.0f, 1.8f, -0.001f),//top right point
		glm::vec3(8.0f, 1.8f, -0.001f),//top right point
		glm::vec3(7.0f, 1.8f, -0.001f),//top left point
		glm::vec3(7.0f, 0.75f, -0.001f),//bottom left point

		//kitchen bottom back
		glm::vec3(1.8f, 1.15f, -0.02f),//bottom left point
		glm::vec3(2.5f, 1.15f, -0.02f),//bottom right point
		glm::vec3(2.5f, 1.8f, -0.02f),//top right point
		glm::vec3(2.5f, 1.8f, -0.02f),//top right point
		glm::vec3(1.8f, 1.8f, -0.02f),//top left point
		glm::vec3(1.8f, 1.15f, -0.02f),//bottom left point
	};
	windowsUD.vertices = {
		//bathroom main
		glm::vec3(4.35f, 1.4f, 5.03f),//bottom left point
		glm::vec3(4.7f, 1.4f, 5.03f),//bottom right point
		glm::vec3(4.7f, 1.8f, 5.03f),//top right point
		glm::vec3(4.7f, 1.8f, 5.03f),//top right point
		glm::vec3(4.35f, 1.8f, 5.03f),//top left point
		glm::vec3(4.35f, 1.4f, 5.03f),//bottom left point

		//garage
		glm::vec3(10.02f, 1.0f, 3.3f),//bottom left point
		glm::vec3(10.02f, 1.0f, 2.6f),//bottom right point
		glm::vec3(10.02f, 1.6f, 2.6f),//top right point
		glm::vec3(10.02f, 1.6f, 2.6f),//top right point
		glm::vec3(10.02f, 1.6f, 3.3f),//top left point
		glm::vec3(10.02f, 1.0f, 3.3f),//bottom left point

		//top far right
		glm::vec3(-0.02f, 2.75f, 4.5f),//bottom left point
		glm::vec3(-0.02f, 2.75f, 3.7f),//bottom right point
		glm::vec3(-0.02f, 3.35f, 3.7f),//top right point
		glm::vec3(-0.02f, 3.35f, 3.7f),//top right point
		glm::vec3(-0.02f, 3.35f, 4.5f),//top left point
		glm::vec3(-0.02f, 2.75f, 4.5f),//bottom left point

		//top left
		glm::vec3(-0.02f, 2.75f, 3.0f),//bottom left point
		glm::vec3(-0.02f, 2.75f, 2.2f),//bottom right point
		glm::vec3(-0.02f, 3.35f, 2.2f),//top right point
		glm::vec3(-0.02f, 3.35f, 2.2f),//top right point
		glm::vec3(-0.02f, 3.35f, 3.0f),//top left point
		glm::vec3(-0.02f, 2.75f, 3.0f),//bottom left point

		//back left
		glm::vec3(9.0f, 0.75f, -0.01f),//bottom left point
		glm::vec3(9.5f, 0.75f, -0.01f),//bottom right point
		glm::vec3(9.5f, 1.5f, -0.01f),//top right point
		glm::vec3(9.5f, 1.5f, -0.01f),//top right point
		glm::vec3(9.0f, 1.5f, -0.01f),//top left point
		glm::vec3(9.0f, 0.75f, -0.01f),//bottom left point

		//left outlet face
		glm::vec3(3.0f, 0.7f, -0.05f),//bottom left point
		glm::vec3(3.27f, 0.7f, -0.232f),//bottom right point
		glm::vec3(3.27f, 1.8f, -0.232f),//top right point
		glm::vec3(3.27f, 1.8f, -0.232f),//top right point
		glm::vec3(3.0f, 1.8f, -0.05f),//top left point
		glm::vec3(3.0f, 0.7f, -0.05f),//bottom left point

		//front outlet face
		glm::vec3(3.37f, 0.7f, -0.261f),//bottom left point
		glm::vec3(4.23f, 0.7f, -0.261f),//bottom right point
		glm::vec3(4.23f, 1.8f, -0.261f),//top right point
		glm::vec3(4.23f, 1.8f, -0.261f),//top right point
		glm::vec3(3.37f, 1.8f, -0.261f),//top left point
		glm::vec3(3.37f, 0.7f, -0.261f),//bottom left point

		//right outlet face
		glm::vec3(4.64f, 0.7f, -0.04f),//bottom left
		glm::vec3(4.35f, 0.7f, -0.222f),//bottom right
		glm::vec3(4.35f, 1.8f, -0.222f),//top right
		glm::vec3(4.35f, 1.8f, -0.222f),//top right
		glm::vec3(4.64f, 1.8f, -0.04f),//top left
		glm::vec3(4.64f, 0.7f, -0.04f),//bottom left
	};
	pyramid.vertices = {
		//back face
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left point
		glm::vec3(1.0f, 0.0f, 0.0f),//bottom right point
		glm::vec3(0.5f, 1.0f, 0.5f),//top right point
		
		//front face
		glm::vec3(0.0f, 0.0f, 1.0f),//top right point
		glm::vec3(1.0f, 0.0f, 1.0f),//top left point
		glm::vec3(0.5f, 1.0f, 0.5f),//bottom left point

		//left face
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left point
		glm::vec3(0.0f, 0.0f, 1.0f),//bottom right point
		glm::vec3(0.5f, 1.0f, 0.5f),//top right point

		//right face
		glm::vec3(1.0f, 0.0f, 0.0f),//bottom left point
		glm::vec3(1.0f, 0.0f, 1.0f),//bottom right point
		glm::vec3(0.5f, 1.0f, 0.5f),//top right point
		
		//base
		glm::vec3(0.0f, 0.0f, 0.0f),//top right point
		glm::vec3(0.0f, 0.0f, 1.0f),//top left point
		glm::vec3(1.0f, 0.0f, 1.0f),//bottom left point

		glm::vec3(1.0f, 0.0f, 1.0f),//top right point
		glm::vec3(1.0f, 0.0f, 0.0f),//top left point
		glm::vec3(0.0f, 0.0f, 0.0f),//bottom left point
	};
	frontDoor.vertices = {
		glm::vec3(0.0f, 0.5f, 5.02f),//todo: comment these
		glm::vec3(0.8f, 0.5f, 5.02f),//todo: comment these
		glm::vec3(0.8f, 1.8f, 5.02f),//todo: comment these
		glm::vec3(0.8f, 1.8f, 5.02f),//todo: comment these
		glm::vec3(0.0f, 1.8f, 5.02f),//todo: comment these
		glm::vec3(0.0f, 0.5f, 5.02f),//todo: comment these
	};
	backStairs.vertices = {
		//top flat
		glm::vec3(0.0f, 0.3f, 0.0f),//bl
		glm::vec3(1.4f, 0.3f, 0.0f),//br
		glm::vec3(1.4f, 0.3f, -0.25f),//tr
		glm::vec3(1.4f, 0.3f, -0.25),//tr
		glm::vec3(0.0f, 0.3f, -0.25f),//tl
		glm::vec3(0.0f, 0.3f, 0.0f),//bl
		//top wall
		glm::vec3(0.0f, 0.15f, -0.25f),//bl
		glm::vec3(1.4f, 0.15f, -0.25f),//br
		glm::vec3(1.4f, 0.3f, -0.25f),//tr
		glm::vec3(1.4f, 0.3f, -0.25),//tr
		glm::vec3(0.0f, 0.3f, -0.25f),//tl
		glm::vec3(0.0f, 0.15f, -0.25f),//bl
		//bottom flat
		glm::vec3(0.0f, 0.15f, -0.25f),//bl
		glm::vec3(1.4f, 0.15f, -0.25f),//br
		glm::vec3(1.4f, 0.15f, -0.5f),//tr
		glm::vec3(1.4f, 0.15f, -0.5),//tr
		glm::vec3(0.0f, 0.15f, -0.5f),//tl
		glm::vec3(0.0f, 0.15f, -0.25f),//bl
		//bottom wall
		glm::vec3(0.0f, 0.0f, -0.5f),//bl
		glm::vec3(1.4f, 0.0f, -0.5f),//br
		glm::vec3(1.4f, 0.15f, -0.5f),//tr
		glm::vec3(1.4f, 0.15f, -0.5),//tr
		glm::vec3(0.0f, 0.15f, -0.5f),//tl
		glm::vec3(0.0f, 0.0f, -0.5f),//bl
		//left wall
		glm::vec3(0.0f, 0.0f, 0.0f),//bl
		glm::vec3(0.0f, 0.0f, -0.5f),//br
		glm::vec3(0.0f, 0.15f, -0.5f),//tr
		glm::vec3(0.0f, 0.15f, -0.5),//tr
		glm::vec3(0.0f, 0.15f, 0.0f),//tl
		glm::vec3(0.0f, 0.0f, 0.0f),//bl

		glm::vec3(0.0f, 0.15f, 0.0f),//bl
		glm::vec3(0.0f, 0.15f, -0.25f),//br
		glm::vec3(0.0f, 0.3f, -0.25f),//tr
		glm::vec3(0.0f, 0.3f, -0.25),//tr
		glm::vec3(0.0f, 0.3f, 0.0f),//tl
		glm::vec3(0.0f, 0.15f, 0.0f),//bl
		//right wall
		glm::vec3(1.4f, 0.0f, 0.0f),//bl
		glm::vec3(1.4f, 0.0f, -0.5f),//br
		glm::vec3(1.4f, 0.15f, -0.5f),//tr
		glm::vec3(1.4f, 0.15f, -0.5),//tr
		glm::vec3(1.4f, 0.15f, 0.0f),//tl
		glm::vec3(1.4f, 0.0f, 0.0f),//bl

		glm::vec3(1.4f, 0.15f, 0.0f),//bl
		glm::vec3(1.4f, 0.15f, -0.25f),//br
		glm::vec3(1.4f, 0.3f, -0.25f),//tr
		glm::vec3(1.4f, 0.3f, -0.25),//tr
		glm::vec3(1.4f, 0.3f, 0.0f),//tl
		glm::vec3(1.4f, 0.15f, 0.0f),//bl
		//garage flat
		glm::vec3(3.2f, 0.15f, 0.0f),//bl
		glm::vec3(3.8f, 0.15f, 0.0f),//br
		glm::vec3(3.8f, 0.15f, -0.25f),//tr
		glm::vec3(3.8f, 0.15f, -0.25),//tr
		glm::vec3(3.2f, 0.15f, -0.25f),//tl
		glm::vec3(3.2f, 0.15f, 0.0f),//bl
		//garage wall
		glm::vec3(3.2f, 0.0f, -0.25f),//bl
		glm::vec3(3.8f, 0.0f, -0.25f),//br
		glm::vec3(3.8f, 0.15f, -0.25f),//tr
		glm::vec3(3.8f, 0.15f, -0.25),//tr
		glm::vec3(3.2f, 0.15f, -0.25f),//tl
		glm::vec3(3.2f, 0.0f, -0.25f),//bl
		//right wall
		glm::vec3(3.8f, 0.0f, 0.0f),//bl
		glm::vec3(3.8f, 0.0f, -0.25f),//br
		glm::vec3(3.8f, 0.15f, -0.25f),//tr
		glm::vec3(3.8f, 0.15f, -0.25),//tr
		glm::vec3(3.8f, 0.15f, 0.0f),//tl
		glm::vec3(3.8f, 0.0f, 0.0f),//bl
		//left wall
		glm::vec3(3.2f, 0.0f, 0.0f),//bl
		glm::vec3(3.2f, 0.0f, -0.25f),//br
		glm::vec3(3.2f, 0.15f, -0.25f),//tr
		glm::vec3(3.2f, 0.15f, -0.25),//tr
		glm::vec3(3.2f, 0.15f, 0.0f),//tl
		glm::vec3(3.2f, 0.0f, 0.0f),//bl
		//back pad
		glm::vec3(-0.25f, 0.02f, 0.0f),//bl
		glm::vec3(4.0f, 0.02f, 0.0f),//br
		glm::vec3(4.0f, 0.02f, -2.0f),//tr
		glm::vec3(4.0f, 0.02f, -2.0),//tr
		glm::vec3(-0.25f, 0.02f, -2.0f),//tl
		glm::vec3(-0.25f, 0.02f, 0.0f),//bl
	};
	backDoor.vertices = {
		//door
		glm::vec3(1.4f, 0.3f, -0.02f),//bl
		glm::vec3(0.0f, 0.3f, -0.02f),//br
		glm::vec3(0.0f, 1.8f, -0.02f),//tr
		glm::vec3(0.0f, 1.8f, -0.02),//tr
		glm::vec3(1.4f, 1.8f, -0.02f),//tl
		glm::vec3(1.4f, 0.3f, -0.02f),//bl
	};
	garageDoors.vertices = {
		//door
		glm::vec3(3.8f, 0.15f, -0.02f),//bl
		glm::vec3(3.2f, 0.15f, -0.02f),//br
		glm::vec3(3.2f, 1.6f, -0.02f),//tr
		glm::vec3(3.2f, 1.6f, -0.02),//tr
		glm::vec3(3.8f, 1.6f, -0.02f),//tl
		glm::vec3(3.8f, 0.15f, -0.02f),//bl
		//door
		glm::vec3(5.01f, 0.0f, 5.4),//bl
		glm::vec3(5.01f, 0.0f, 4.8f),//br
		glm::vec3(5.01f, 1.3f, 4.8f),//tr
		glm::vec3(5.01f, 1.3f, 4.8),//tr
		glm::vec3(5.01f, 1.3f, 5.4f),//tl
		glm::vec3(5.01f, 0.0f, 5.4f),//bl
	};
	bushes.vertices = {
		//back
		glm::vec3(-0.55f, 0.0f, 0.0f),//bl
		glm::vec3(-0.05f, 0.0f, 0.0f),//br
		glm::vec3(-0.05f, 1.0f, 0.0f),//tr
		glm::vec3(-0.05f, 1.0f, 0.0f),//tr
		glm::vec3(-0.55f, 1.0f, 0.0f),//tl
		glm::vec3(-0.55f, 0.0f, 0.0f),//bl
		//left
		glm::vec3(-0.55f, 0.0f, 0.0f),//bl
		glm::vec3(-0.55f, 0.0f, 1.0f),//br
		glm::vec3(-0.55f, 1.0f, 1.0f),//tr
		glm::vec3(-0.55f, 1.0f, 1.0f),//tr
		glm::vec3(-0.55f, 1.0f, 0.0f),//tl
		glm::vec3(-0.55f, 0.0f, 0.0f),//bl
		//front
		glm::vec3(-0.55f, 0.0f, 1.0f),//bl
		glm::vec3(-0.05f, 0.0f, 1.0f),//br
		glm::vec3(-0.05f, 1.0f, 1.0f),//tr
		glm::vec3(-0.05f, 1.0f, 1.0f),//tr
		glm::vec3(-0.55f, 1.0f, 1.0f),//tl
		glm::vec3(-0.55f, 0.0f, 1.0f),//bl
		//right
		glm::vec3(-0.05f, 0.0f, 0.0f),//bl
		glm::vec3(-0.05f, 0.0f, 1.0f),//br
		glm::vec3(-0.05f, 1.0f, 1.0f),//tr
		glm::vec3(-0.05f, 1.0f, 1.0f),//tr
		glm::vec3(-0.05f, 1.0f, 0.0f),//tl
		glm::vec3(-0.05f, 0.0f, 0.0f),//bl
		//top
		glm::vec3(-0.55f, 1.0f, 0.0f),//bl
		glm::vec3(-0.05f, 1.0f, 0.0f),//br
		glm::vec3(-0.05f, 1.0f, 1.0f),//tr
		glm::vec3(-0.05f, 1.0f, 1.0f),//tr
		glm::vec3(-0.55f, 1.0f, 1.0f),//tl
		glm::vec3(-0.55f, 1.0f, 0.0f),//bl


		//back
		glm::vec3(-0.55f, 0.0f, 3.8f),//bl
		glm::vec3(-0.05f, 0.0f, 3.8f),//br
		glm::vec3(-0.05f, 1.0f, 3.8f),//tr
		glm::vec3(-0.05f, 1.0f, 3.8f),//tr
		glm::vec3(-0.55f, 1.0f, 3.8f),//tl
		glm::vec3(-0.55f, 0.0f, 3.8f),//bl
		//left
		glm::vec3(-0.55f, 0.0f, 3.8f),//bl
		glm::vec3(-0.55f, 0.0f, 4.8f),//br
		glm::vec3(-0.55f, 1.0f, 4.8f),//tr
		glm::vec3(-0.55f, 1.0f, 4.8f),//tr
		glm::vec3(-0.55f, 1.0f, 3.8f),//tl
		glm::vec3(-0.55f, 0.0f, 3.8f),//bl
		//front
		glm::vec3(-0.55f, 0.0f, 4.8f),//bl
		glm::vec3(-0.05f, 0.0f, 4.8f),//br
		glm::vec3(-0.05f, 1.0f, 4.8f),//tr
		glm::vec3(-0.05f, 1.0f, 4.8f),//tr
		glm::vec3(-0.55f, 1.0f, 4.8f),//tl
		glm::vec3(-0.55f, 0.0f, 4.8f),//bl
		//right
		glm::vec3(-0.05f, 0.0f, 3.8f),//bl
		glm::vec3(-0.05f, 0.0f, 4.8f),//br
		glm::vec3(-0.05f, 1.0f, 4.8f),//tr
		glm::vec3(-0.05f, 1.0f, 4.8f),//tr
		glm::vec3(-0.05f, 1.0f, 3.8f),//tl
		glm::vec3(-0.05f, 0.0f, 3.8f),//bl
		//top
		glm::vec3(-0.55f, 1.0f, 3.8f),//bl
		glm::vec3(-0.05f, 1.0f, 3.8f),//br
		glm::vec3(-0.05f, 1.0f, 4.8f),//tr
		glm::vec3(-0.05f, 1.0f, 4.8f),//tr
		glm::vec3(-0.55f, 1.0f, 4.8f),//tl
		glm::vec3(-0.55f, 1.0f, 3.8f),//bl


		//back
		glm::vec3(10.05f, 0.0f, 3.4f),//bl
		glm::vec3(10.55f, 0.0f, 3.4f),//br
		glm::vec3(10.55f, 1.0f, 3.4f),//tr
		glm::vec3(10.55f, 1.0f, 3.4f),//tr
		glm::vec3(10.05f, 1.0f, 3.4f),//tl
		glm::vec3(10.05f, 0.0f, 3.4f),//bl
		//left
		glm::vec3(10.05f, 0.0f, 3.4f),//bl
		glm::vec3(10.05f, 0.0f, 4.4f),//br
		glm::vec3(10.05f, 1.0f, 4.4f),//tr
		glm::vec3(10.05f, 1.0f, 4.4f),//tr
		glm::vec3(10.05f, 1.0f, 3.4f),//tl
		glm::vec3(10.05f, 0.0f, 3.4f),//bl
		//front
		glm::vec3(10.05f, 0.0f, 4.4f),//bl
		glm::vec3(10.55f, 0.0f, 4.4f),//br
		glm::vec3(10.55f, 1.0f, 4.4f),//tr
		glm::vec3(10.55f, 1.0f, 4.4f),//tr
		glm::vec3(10.05f, 1.0f, 4.4f),//tl
		glm::vec3(10.05f, 0.0f, 4.4f),//bl
		//right
		glm::vec3(10.55f, 0.0f, 3.4f),//bl
		glm::vec3(10.55f, 0.0f, 4.4f),//br
		glm::vec3(10.55f, 1.0f, 4.4f),//tr
		glm::vec3(10.55f, 1.0f, 4.4f),//tr
		glm::vec3(10.55f, 1.0f, 3.4f),//tl
		glm::vec3(10.55f, 0.0f, 3.4f),//bl
		//top
		glm::vec3(10.05f, 1.0f, 3.4f),//bl
		glm::vec3(10.55f, 1.0f, 3.4f),//br
		glm::vec3(10.55f, 1.0f, 4.4f),//tr
		glm::vec3(10.55f, 1.0f, 4.4f),//tr
		glm::vec3(10.05f, 1.0f, 4.4f),//tl
		glm::vec3(10.05f, 1.0f, 3.4f),//bl


		//back
		glm::vec3(-0.55f, 0.0f, 3.2f),//bl
		glm::vec3(-0.05f, 0.0f, 3.2f),//br
		glm::vec3(-0.05f, 0.5f, 3.2f),//tr
		glm::vec3(-0.05f, 0.5f, 3.2f),//tr
		glm::vec3(-0.55f, 0.5f, 3.2f),//tl
		glm::vec3(-0.55f, 0.0f, 3.2f),//bl
		//left
		glm::vec3(-0.55f, 0.0f, 3.2f),//bl
		glm::vec3(-0.55f, 0.0f, 1.5f),//br
		glm::vec3(-0.55f, 0.5f, 1.5f),//tr
		glm::vec3(-0.55f, 0.5f, 1.5f),//tr
		glm::vec3(-0.55f, 0.5f, 3.2f),//tl
		glm::vec3(-0.55f, 0.0f, 3.2f),//bl
		//front
		glm::vec3(-0.55f, 0.0f, 1.5f),//bl
		glm::vec3(-0.05f, 0.0f, 1.5f),//br
		glm::vec3(-0.05f, 0.5f, 1.5f),//tr
		glm::vec3(-0.05f, 0.5f, 1.5f),//tr
		glm::vec3(-0.55f, 0.5f, 1.5f),//tl
		glm::vec3(-0.55f, 0.0f, 1.5f),//bl
		//right
		glm::vec3(-0.05f, 0.0f, 3.2f),//bl
		glm::vec3(-0.05f, 0.0f, 1.5f),//br
		glm::vec3(-0.05f, 0.5f, 1.5f),//tr
		glm::vec3(-0.05f, 0.5f, 1.5f),//tr
		glm::vec3(-0.05f, 0.5f, 3.2f),//tl
		glm::vec3(-0.05f, 0.0f, 3.2f),//bl
		//top
		glm::vec3(-0.55f, 0.5f, 3.2f),//bl
		glm::vec3(-0.05f, 0.5f, 3.2f),//br
		glm::vec3(-0.05f, 0.5f, 1.5f),//tr
		glm::vec3(-0.05f, 0.5f, 1.5f),//tr
		glm::vec3(-0.55f, 0.5f, 1.5f),//tl
		glm::vec3(-0.55f, 0.5f, 3.2f),//bl


		//back
		glm::vec3(10.05f, 0.0f, 2.4f),//bl
		glm::vec3(10.55f, 0.0f, 2.4f),//br
		glm::vec3(10.55f, 0.5f, 2.4f),//tr
		glm::vec3(10.55f, 0.5f, 2.4f),//tr
		glm::vec3(10.05f, 0.5f, 2.4f),//tl
		glm::vec3(10.05f, 0.0f, 2.4f),//bl
		//left
		glm::vec3(10.05f, 0.0f, 2.4f),//bl
		glm::vec3(10.05f, 0.0f, 2.8f),//br
		glm::vec3(10.05f, 0.5f, 2.8f),//tr
		glm::vec3(10.05f, 0.5f, 2.8f),//tr
		glm::vec3(10.05f, 0.5f, 2.4f),//tl
		glm::vec3(10.05f, 0.0f, 2.4f),//bl
		//front
		glm::vec3(10.05f, 0.0f, 2.8f),//bl
		glm::vec3(10.55f, 0.0f, 2.8f),//br
		glm::vec3(10.55f, 0.5f, 2.8f),//tr
		glm::vec3(10.55f, 0.5f, 2.8f),//tr
		glm::vec3(10.05f, 0.5f, 2.8f),//tl
		glm::vec3(10.05f, 0.0f, 2.8f),//bl
		//right
		glm::vec3(10.55f, 0.0f, 2.4f),//bl
		glm::vec3(10.55f, 0.0f, 2.8f),//br
		glm::vec3(10.55f, 0.5f, 2.8f),//tr
		glm::vec3(10.55f, 0.5f, 2.8f),//tr
		glm::vec3(10.55f, 0.5f, 2.4f),//tl
		glm::vec3(10.55f, 0.0f, 2.4f),//bl
		//top
		glm::vec3(10.05f, 0.5f, 2.4f),//bl
		glm::vec3(10.55f, 0.5f, 2.4f),//br
		glm::vec3(10.55f, 0.5f, 2.8f),//tr
		glm::vec3(10.55f, 0.5f, 2.8f),//tr
		glm::vec3(10.05f, 0.5f, 2.8f),//tl
		glm::vec3(10.05f, 0.5f, 2.4f),//bl
	};

	//Texture Coords
	firstFloorBrick.texcoords = {
		//front left face -- front window and door
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(3.0f, 0.0f),//bottom right point
		glm::vec2(3.0f, 3.0f),//top right point
		glm::vec2(3.0f, 3.0f),//top right point
		glm::vec2(0.0f, 3.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front front middle face -- small side on porch near garage
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(3.0f, 0.0f),//bottom right point
		glm::vec2(3.0f, 3.0f),//top right point
		glm::vec2(3.0f, 3.0f),//top right point
		glm::vec2(0.0f, 3.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front middle face -- single car garage
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(3.0f, 0.0f),//bottom right point
		glm::vec2(3.0f, 3.0f),//top right point
		glm::vec2(3.0f, 3.0f),//top right point
		glm::vec2(0.0f, 3.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front right face -- small segment between garage
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(3.0f, 0.0f),//bottom right point
		glm::vec2(3.0f, 3.0f),//top right point
		glm::vec2(3.0f, 3.0f),//top right point
		glm::vec2(0.0f, 3.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front right face -- double car garage
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(3.0f, 0.0f),//bottom right point
		glm::vec2(3.0f, 3.0f),//top right point
		glm::vec2(3.0f, 3.0f),//top right point
		glm::vec2(0.0f, 3.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point
	};
	firstFloorSiding.texcoords = {
		//back face -- back of house
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//left side face
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//right side face
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//above single garage
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//above double garage
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left
	};
	firstFloorRoof.texcoords = {

		//left face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//left corner
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//under left window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//under left window to the right
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//middle roof
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//under right window to the left
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//under right window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//under right window to the right
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//right corner
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//back face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
	};
	secondFloor.texcoords = {
		//back face -- back of house
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//left face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front face -- left of window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front face -- left side of window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front face -- left window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front face -- right side of window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front face -- right of window
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//front face -- going back to middle
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//front face -- middle
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//front face -- going back to middle
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//front face -- left of right window
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//front face -- left side of window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point

		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front face -- right window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front face -- left side of window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front face -- right of right window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//left face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point
	};
	secondFloorRoof.texcoords = {
		//left face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point (middle)

		//right face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top left point

		//back face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point
	};
	windowPyramidBig.texcoords = {
		//front face -- left window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point (middle)

		//left face -- left window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//right face -- left window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front face -- right window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point (middle)

		//left face -- right window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//right face -- right window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

	};
	windowPyramidSmall.texcoords = {
		//front face -- left window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point (middle)

		//left face -- left window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//right face -- left window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front face -- right window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point (middle)

		//left face -- right window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//right face -- right window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point
	};
	plane.texcoords = {
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
	};
	porch.texcoords = {
		//front cube face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//left cube face
		glm::vec2(1.0f, 0.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(1.0f, 0.0f),//bottom left

		//top cube face
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left
	};
	singleGarage.texcoords = {
		//back cube face 
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front cube face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//left cube face
		glm::vec2(1.0f, 0.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(1.0f, 0.0f),//bottom left

		//right cube face
		glm::vec2(1.0f, 0.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(1.0f, 0.0f),//bottom left

		//bottom cube face
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//top cube face
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left
	};
	doubleGarage.texcoords = {
		//back cube face 
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front cube face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//left cube face
		glm::vec2(1.0f, 0.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(1.0f, 0.0f),//bottom left

		//right cube face
		glm::vec2(1.0f, 0.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(1.0f, 0.0f),//bottom left

		//bottom cube face
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//top cube face
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left
	};
	siding.texcoords = {
		//FRONT PORCH OUTLET
		//left outlet face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front outlet face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//right outlet face
		glm::vec2(0.0f, 0.0f),//bottom left
		glm::vec2(1.0f, 0.0f),//bottom right
		glm::vec2(1.0f, 1.0f),//top right
		glm::vec2(1.0f, 1.0f),//top right
		glm::vec2(0.0f, 1.0f),//top left
		glm::vec2(0.0f, 0.0f),//bottom left

		//master bedroom outlet
		//back face
		glm::vec2(0.0f, 0.0f),//bottom left
		glm::vec2(1.0f, 0.0f),//bottom right
		glm::vec2(1.0f, 1.0f),//top right
		glm::vec2(1.0f, 1.0f),//top right
		glm::vec2(0.0f, 1.0f),//top left
		glm::vec2(0.0f, 0.0f),//bottom left

		//left face
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//right face
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//bottom face
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//second floor outlet
		//back face
		glm::vec2(0.0f, 0.0f),//bottom left
		glm::vec2(1.0f, 0.0f),//bottom right
		glm::vec2(1.0f, 1.0f),//top right
		glm::vec2(1.0f, 1.0f),//top right
		glm::vec2(0.0f, 1.0f),//top left
		glm::vec2(0.0f, 0.0f),//bottom left

		//left face
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//right face
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//bottom face
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//kitchen outlet
		//left outlet face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front outlet face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//right outlet face
		glm::vec2(0.0f, 0.0f),//bottom left
		glm::vec2(.25f, 0.0f),//bottom right
		glm::vec2(.25f, 1.0f),//top right
		glm::vec2(.25f, 1.0f),//top right
		glm::vec2(0.0f, 1.0f),//top left
		glm::vec2(0.0f, 0.0f),//bottom left

		//SECOND FLOOR ROOF FLASHING
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//big pyramid -- left window
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//little pyramid -- left window
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//big pyramid -- right window
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//little pyramid -- right window
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//FIRST FLOOR FLASHING
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//PORCH PYRAMID FLASHING
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left
	};
	porchCol.texcoords = {
		//far left col
		//back cube face 
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(0.0f, 1.0f),//bottom right point
		glm::vec2(1.0f, 0.0f),//top right point
		glm::vec2(1.0f, 0.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(1.0f, 1.0f),//bottom left point

		//front cube face
		glm::vec2(0.5f, 0.0f),//bottom left point
		glm::vec2(0.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 0.0f),//top right point
		glm::vec2(0.0f, 0.5f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//left cube face
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 0.0f),//bottom right
		glm::vec2(0.0f, 0.0f),//top right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(1.0f, 1.0f),//top left
		glm::vec2(1.0f, 0.0f),//bottom left

		//right cube face
		glm::vec2(1.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 0.0f),//bottom right
		glm::vec2(0.0f, 0.0f),//top right
		glm::vec2(1.0f, 1.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//small middle col
		//back cube face 
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front cube face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//left cube face
		glm::vec2(1.0f, 0.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(1.0f, 0.0f),//bottom left

		//right cube face
		glm::vec2(1.0f, 0.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(1.0f, 0.0f),//bottom left

		//small right col
		//back cube face 
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front cube face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//left cube face
		glm::vec2(1.0f, 0.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(1.0f, 0.0f),//bottom left

		//right cube face
		glm::vec2(1.0f, 0.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(1.0f, 0.0f),//bottom left

		//big left col
		//back cube face 
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point
		//additions
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front cube face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point
		//additions
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//left cube face
		glm::vec2(1.0f, 0.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(1.0f, 0.0f),//bottom left

		//additions
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//right cube face
		glm::vec2(1.0f, 0.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(1.0f, 0.0f),//bottom left
		
		//additions
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//big right col
		//back cube face 
			glm::vec2(0.0f, 0.0f),//bottom left point
			glm::vec2(1.0f, 0.0f),//bottom right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(0.0f, 1.0f),//top left point
			glm::vec2(0.0f, 0.0f),//bottom left point
			//additions
			glm::vec2(0.0f, 0.0f),//bottom left point
			glm::vec2(1.0f, 0.0f),//bottom right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(0.0f, 1.0f),//top left point
			glm::vec2(0.0f, 0.0f),//bottom left point

			glm::vec2(0.0f, 0.0f),//bottom left point
			glm::vec2(1.0f, 0.0f),//bottom right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(0.0f, 1.0f),//top left point
			glm::vec2(0.0f, 0.0f),//bottom left point

			glm::vec2(0.0f, 0.0f),//bottom left point
			glm::vec2(1.0f, 0.0f),//bottom right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(0.0f, 1.0f),//top left point
			glm::vec2(0.0f, 0.0f),//bottom left point

			//front cube face
			glm::vec2(0.0f, 0.0f),//bottom left point
			glm::vec2(1.0f, 0.0f),//bottom right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(0.0f, 1.0f),//top left point
			glm::vec2(0.0f, 0.0f),//bottom left point
			//additions
			glm::vec2(0.0f, 0.0f),//bottom left point
			glm::vec2(1.0f, 0.0f),//bottom right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(0.0f, 1.0f),//top left point
			glm::vec2(0.0f, 0.0f),//bottom left point

			glm::vec2(0.0f, 0.0f),//bottom left point
			glm::vec2(1.0f, 0.0f),//bottom right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(0.0f, 1.0f),//top left point
			glm::vec2(0.0f, 0.0f),//bottom left point

			glm::vec2(0.0f, 0.0f),//bottom left point
			glm::vec2(1.0f, 0.0f),//bottom right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(0.0f, 1.0f),//top left point
			glm::vec2(0.0f, 0.0f),//bottom left point

			//left cube face
			glm::vec2(1.0f, 0.0f),//bottom left
			glm::vec2(1.0f, 1.0f),//bottom right
			glm::vec2(0.0f, 1.0f),//top right
			glm::vec2(0.0f, 1.0f),//top right
			glm::vec2(0.0f, 0.0f),//top left
			glm::vec2(1.0f, 0.0f),//bottom left

			//additions
			glm::vec2(0.0f, 0.0f),//bottom left point
			glm::vec2(1.0f, 0.0f),//bottom right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(0.0f, 1.0f),//top left point
			glm::vec2(0.0f, 0.0f),//bottom left point

			glm::vec2(0.0f, 0.0f),//bottom left point
			glm::vec2(1.0f, 0.0f),//bottom right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(0.0f, 1.0f),//top left point
			glm::vec2(0.0f, 0.0f),//bottom left point

			glm::vec2(0.0f, 0.0f),//bottom left point
			glm::vec2(1.0f, 0.0f),//bottom right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(0.0f, 1.0f),//top left point
			glm::vec2(0.0f, 0.0f),//bottom left point

			//right cube face
			glm::vec2(1.0f, 0.0f),//bottom left
			glm::vec2(1.0f, 1.0f),//bottom right
			glm::vec2(0.0f, 1.0f),//top right
			glm::vec2(0.0f, 1.0f),//top right
			glm::vec2(0.0f, 0.0f),//top left
			glm::vec2(1.0f, 0.0f),//bottom left

			//additions
			glm::vec2(0.0f, 0.0f),//bottom left point
			glm::vec2(1.0f, 0.0f),//bottom right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(0.0f, 1.0f),//top left point
			glm::vec2(0.0f, 0.0f),//bottom left point

			glm::vec2(0.0f, 0.0f),//bottom left point
			glm::vec2(1.0f, 0.0f),//bottom right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(0.0f, 1.0f),//top left point
			glm::vec2(0.0f, 0.0f),//bottom left point

			glm::vec2(0.0f, 0.0f),//bottom left point
			glm::vec2(1.0f, 0.0f),//bottom right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(1.0f, 1.0f),//top right point
			glm::vec2(0.0f, 1.0f),//top left point
			glm::vec2(0.0f, 0.0f),//bottom left point
	};
	smallCol.texcoords = {//back cube face 
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front cube face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//left cube face
		glm::vec2(1.0f, 0.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(1.0f, 0.0f),//bottom left

		//right cube face
		glm::vec2(1.0f, 0.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 1.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(1.0f, 0.0f),//bottom left

		//bottom cube face
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left

		//top cube face
		glm::vec2(0.0f, 1.0f),//bottom left
		glm::vec2(1.0f, 1.0f),//bottom right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(1.0f, 0.0f),//top right
		glm::vec2(0.0f, 0.0f),//top left
		glm::vec2(0.0f, 1.0f),//bottom left
	}; //NOT NEEDED
	frontStairs.texcoords = {
		//Garden box needs to be .3 tall, 6 long, 1.2 in depth
		//stairs are 1.5 long, .1 tall, .1 in depth
		//back face 
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//left face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//right cube face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//stairs start here. x value of 2
		//first stair flat
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//second stair flat
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//third stair flat
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//first stair wall
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//second stair wall
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//left stair sidewall
		//top stair
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//second stair
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//third stair
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//right stair sidewall
		//top stair
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//second stair
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//third stair
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//pad - top
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//pad - front wall
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//pad - front wall
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//pad - left wall
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//single stair
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point
	};
	mulch.texcoords = {
		//front cube face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.5f, 0.0f),//bottom right point
		glm::vec2(1.5f, 1.5f),//top right point
		glm::vec2(1.5f, 1.5f),//top right point
		glm::vec2(0.0f, 1.5f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point
	};
	garage.texcoords = {
		//single
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//double
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point
	};
	porchPyramid.texcoords = {
		//front face -- left window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point (middle)

		//left face -- left window
		glm::vec2(1.0f, 1.0f),//bottom left
		glm::vec2(0.0f, 1.0f),//bottom right
		glm::vec2(0.0f, 0.0f),//top right point
		glm::vec2(3.0f, 3.0f),//top right point
		glm::vec2(0.0f, 3.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//right face -- left window
		glm::vec2(1.0f, 1.0f),//bottom left
		glm::vec2(0.0f, 1.0f),//bottom right
		glm::vec2(0.0f, 0.0f),//top right point
		glm::vec2(3.0f, 3.0f),//top right point
		glm::vec2(0.0f, 3.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point
	};
	garagePyramid.texcoords = {
		//front face -- left window
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point (middle)

		//left face -- left window
		glm::vec2(1.0f, 1.0f),//bottom left
		glm::vec2(0.0f, 1.0f),//bottom right
		glm::vec2(0.0f, 0.0f),//top right point
		glm::vec2(3.0f, 3.0f),//top right point
		glm::vec2(0.0f, 3.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//right face -- left window
		glm::vec2(1.0f, 1.0f),//bottom left
		glm::vec2(0.0f, 1.0f),//bottom right
		glm::vec2(0.0f, 0.0f),//top right point
		glm::vec2(3.0f, 3.0f),//top right point
		glm::vec2(0.0f, 3.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point
	};
	porchFence.texcoords = {
		//left face
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front face left
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front face right
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//stairs left
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//stairs right
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point

		//front face forward
		glm::vec2(0.0f, 0.0f),//bottom left point
		glm::vec2(1.0f, 0.0f),//bottom right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(1.0f, 1.0f),//top right point
		glm::vec2(0.0f, 1.0f),//top left point
		glm::vec2(0.0f, 0.0f),//bottom left point
	};
	pyramid.texcoords = {
			glm::vec2(0.0f, 0.0f),//bottom left point
			glm::vec2(1.0f, 0.0f),//bottom right point
			glm::vec2(1.0f, 1.0f),//top right point (middle)

			glm::vec2(1.0f, 1.0f),//bottom left
			glm::vec2(0.0f, 1.0f),//bottom right
			glm::vec2(0.0f, 0.0f),//top right point

			glm::vec2(3.0f, 3.0f),//top right point
			glm::vec2(0.0f, 3.0f),//top left point
			glm::vec2(0.0f, 0.0f),//bottom left point

			glm::vec2(1.0f, 1.0f),//bottom left
			glm::vec2(0.0f, 1.0f),//bottom right
			glm::vec2(0.0f, 0.0f),//top right point

			glm::vec2(3.0f, 3.0f),//top right point
			glm::vec2(0.0f, 3.0f),//top left point
			glm::vec2(0.0f, 0.0f),//bottom left point

			glm::vec2(0.0f, 0.0f),//bottom left point
			glm::vec2(1.0f, 0.0f),//bottom right point
			glm::vec2(1.0f, 1.0f),//top right point (middle)
	};
	windowsLR.texcoords = {
		//left outlet window
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//front outlet window
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//right outlet window
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//front top left 
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//front top right 
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//left face left 
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//far right top 
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//middle top back 
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//left top back 
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//left bottom back 
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//kitchen bottom back
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//kitchen outlet middle
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
	};
	windowsUD.texcoords = {
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
	};
	frontDoor.texcoords = {
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these	
	};
	backStairs.texcoords = {
		//placehold
			glm::vec2(0.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 0.0f),//todo: comment these
			//placehold
			glm::vec2(0.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 0.0f),//todo: comment these
			//placehold
			glm::vec2(0.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 0.0f),//todo: comment these
			//placehold
			glm::vec2(0.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 0.0f),//todo: comment these
			//placehold
			glm::vec2(0.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 0.0f),//todo: comment these
			//placehold
			glm::vec2(0.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 0.0f),//todo: comment these
			//placehold
			glm::vec2(0.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 0.0f),//todo: comment these
			//placehold
			glm::vec2(0.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 0.0f),//todo: comment these
			//placehold
			glm::vec2(0.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 0.0f),//todo: comment these
			//placehold
			glm::vec2(0.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 0.0f),//todo: comment these
			//placehold
			glm::vec2(0.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 0.0f),//todo: comment these
			//placehold
			glm::vec2(0.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 0.0f),//todo: comment these
			//placehold
			glm::vec2(0.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 0.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(1.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 1.0f),//todo: comment these
			glm::vec2(0.0f, 0.0f),//todo: comment these
	};
	backDoor.texcoords = {
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
	};
	garageDoors.texcoords = {
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
	};
	bushes.texcoords = {
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
		//placehold
		glm::vec2(0.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 0.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(1.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 1.0f),//todo: comment these
		glm::vec2(0.0f, 0.0f),//todo: comment these
	};

	plane.upload();
	porch.upload();
	firstFloorRoof.upload();
	singleGarage.upload();
	doubleGarage.upload();
	siding.upload();
	porchCol.upload();
	firstFloorBrick.upload();
	secondFloor.upload();
	frontStairs.upload();
	garage.upload();
	firstFloorSiding.upload();
	secondFloorRoof.upload();
	windowPyramidBig.upload();
	windowPyramidSmall.upload();
	mulch.upload();
	porchPyramid.upload();
	garagePyramid.upload();
	porchFence.upload();
	windowsLR.upload();
	windowsUD.upload();
	frontDoor.upload();
	backStairs.upload();
	backDoor.upload();
	garageDoors.upload();
	bushes.upload();
	//pyramid.upload();//for testing

	// load and create a texture 
	// -------------------------
	unsigned int texture1, texture2, texture3, texture4, texture5, texture6, texture7, texture8, texture9,
				 texture10, texture11, texture12, texture13, texture14;
	// texture 1
	// ---------
	glGenTextures(1, &texture1);
	glBindTexture(GL_TEXTURE_2D, texture1);
	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	int width, height, nrChannels;
	stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
	unsigned char *data = stbi_load("images/brick.jpg", &width, &height, &nrChannels, 0);
	if (data)
	{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data);
	// texture 2
	// ---------
	glGenTextures(1, &texture2);
	glBindTexture(GL_TEXTURE_2D, texture2);
	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_REPEAT);
	// load image, create texture and generate mipmaps
	width, height, nrChannels;
	stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
	unsigned char* data2 = stbi_load("images/grass.jpg", &width, &height, &nrChannels, 0);
	if (data2)
	{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data2);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data2);

	// texture 3
	// ---------
	glGenTextures(1, &texture3);
	glBindTexture(GL_TEXTURE_2D, texture3);
	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	width, height, nrChannels;
	stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
	unsigned char* data3 = stbi_load("images/shingle.jpg", &width, &height, &nrChannels, 0);
	if (data3)
	{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data3);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data3);

	//texture 4
	glGenTextures(1, &texture4);
	glBindTexture(GL_TEXTURE_2D, texture4);
	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	width, height, nrChannels;
	stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
	unsigned char *data4 = stbi_load("images/siding.jpg", &width, &height, &nrChannels, 0);
	if (data4)
	{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data4);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data4);

	//texture 5
	glGenTextures(1, &texture5);
	glBindTexture(GL_TEXTURE_2D, texture5);
	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	width, height, nrChannels;
	stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
	unsigned char *data5 = stbi_load("images/concrete.jpg", &width, &height, &nrChannels, 0);
	if (data5)
	{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data5);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data5);

	//texture 6
	glGenTextures(1, &texture6);
	glBindTexture(GL_TEXTURE_2D, texture6);
	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	width, height, nrChannels;
	stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
	unsigned char *data6 = stbi_load("images/singleGarage.jfif", &width, &height, &nrChannels, 0);
	if (data6)
	{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data6);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data6);

	//texture 7
	glGenTextures(1, &texture7);
	glBindTexture(GL_TEXTURE_2D, texture7);
	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	width, height, nrChannels;
	stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
	unsigned char *data7 = stbi_load("images/mulch.jpg", &width, &height, &nrChannels, 0);
	if (data7)
	{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data7);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data7);

	//texture 8
	glGenTextures(1, &texture8);
	glBindTexture(GL_TEXTURE_2D, texture8);
	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	width, height, nrChannels;
	stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
	unsigned char *data8 = stbi_load("images/white_Fence.jpg", &width, &height, &nrChannels, 0);
	if (data8)
	{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data8);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data8);

	//texture 9
	glGenTextures(1, &texture9);
	glBindTexture(GL_TEXTURE_2D, texture9);
	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	width, height, nrChannels;
	stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
	unsigned char *data9 = stbi_load("images/window.jpg", &width, &height, &nrChannels, 0);
	if (data9)
	{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data9);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data9);

	//texture 10
	glGenTextures(1, &texture10);
	glBindTexture(GL_TEXTURE_2D, texture10);
	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	width, height, nrChannels;
	stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
	unsigned char *data10 = stbi_load("images/window2.jpg", &width, &height, &nrChannels, 0);
	if (data10)
	{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data10);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data10);

	//texture 11
	glGenTextures(1, &texture11);
	glBindTexture(GL_TEXTURE_2D, texture11);
	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	width, height, nrChannels;
	stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
	unsigned char *data11 = stbi_load("images/frontDoor.jpg", &width, &height, &nrChannels, 0);
	if (data11)
	{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data11);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data11);

	//texture 12
	glGenTextures(1, &texture12);
	glBindTexture(GL_TEXTURE_2D, texture12);
	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	width, height, nrChannels;
	stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
	unsigned char *data12 = stbi_load("images/backDoor.jpg", &width, &height, &nrChannels, 0);
	if (data12)
	{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data12);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data12);

	//texture 13
	glGenTextures(1, &texture13);
	glBindTexture(GL_TEXTURE_2D, texture13);
	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	width, height, nrChannels;
	stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
	unsigned char *data13 = stbi_load("images/garageDoor.jpg", &width, &height, &nrChannels, 0);
	if (data13)
	{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data13);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data13);

	//texture 14
	glGenTextures(1, &texture14);
	glBindTexture(GL_TEXTURE_2D, texture14);
	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	width, height, nrChannels;
	stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
	unsigned char *data14 = stbi_load("images/bush.jpg", &width, &height, &nrChannels, 0);
	if (data14)
	{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data14);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data14);

	// tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
	// -------------------------------------------------------------------------------------------
	//ourShader.use();
	lightingShader.use();


	glm::mat4 model;
	glm::mat4 projection;

	// render loop
	// -----------
	while (!glfwWindowShouldClose(window))
	{
		// per-frame time logic
		// --------------------
		float currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		// input
		// -----
		processInput(window);

		// render
		// ------
		glClearColor(135/256.f, 206/256.f, 235/256.f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// activate shader
		//ourShader.use();
		lightingShader.use();


		if (!orthoView)
		{
			// pass projection matrix to shader (note that in this case it could change every frame)
			projection = glm::perspective(glm::radians(fov), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
		}
		else {
			float scale = 100;
			projection = glm::ortho(-((float)SCR_WIDTH / scale), (float)SCR_WIDTH / scale, -(float)SCR_HEIGHT / scale, ((float)SCR_HEIGHT / scale), -50.0f, 50.0f);
		}
		lightingShader.setMat4("projection", projection);

		glm::vec3 lightPos = glm::vec3(0.0f, 5.0f, 8.0f);
		glm::vec3 lightColor = glm::vec3(1.0f, 1.0f, 1.0f); //This value changes the color of the light
		glm::vec3 objectColor = glm::vec3(0.0f, 0.0f, 1.0f);

		// camera/view transformation
		glm::mat4 view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
		lightingShader.setMat4("view", view);
		lightingShader.setVec3("lightPos", lightPos);
		lightingShader.setVec3("viewPos", cameraPos);

		lightingShader.setVec3("lightColor", lightColor);
		lightingShader.setVec3("objectColor", objectColor);

		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first
		model = glm::translate(model, glm::vec3(-5.0f, -1.5f, -5.0f));
		
		//pyramid.draw(glm::translate(model, glm::vec3(5.0f, 1.0f, 5.0f)), lightingShader, texture2); FOR TESTING ONLY

		
		plane.draw(glm::translate(model, glm::vec3(5.0f, 1.0f, 5.0f)), lightingShader, texture2);
		
		firstFloorBrick.draw(glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0f)), lightingShader, texture1);
		firstFloorSiding.draw(glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0f)), lightingShader, texture4);
		firstFloorRoof.draw(glm::translate(model, glm::vec3(-0.25f, 2.0f, 5.0f)), lightingShader, texture3);
		porch.draw(glm::translate(model, glm::vec3(5.0f, -0.0f, 5.0f)), lightingShader, texture5);
		frontStairs.draw(glm::translate(model, glm::vec3(0.0f, 0.0f, 5.0f)), lightingShader, texture5);
		garage.draw(glm::translate(model, glm::vec3(5.25f, 0.0f, 5.76f)), lightingShader, texture6);
		porchCol.draw(glm::translate(model, glm::vec3(0.0f, 0.5f, 5.58f)), lightingShader, texture1);
		mulch.draw(glm::translate(model, glm::vec3(-0.75f, 0.18f, 5.05f)), lightingShader, texture7);
		porchPyramid.draw(glm::translate(model, glm::vec3(2.0f, 2.125f, 6.25f)), lightingShader, texture3);
		garagePyramid.draw(glm::translate(model, glm::vec3(6.75f, 2.0f, 6.25f)), lightingShader, texture3);
		siding.draw(glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0f)), lightingShader, texture4);
		porchFence.draw(glm::translate(model, glm::vec3(0.05f, 0.5f, 5.0f)), lightingShader, texture8);
		
		secondFloor.draw(glm::translate(model, glm::vec3(0.0f, 2.0f, 0.0f)), lightingShader, texture4);
		secondFloorRoof.draw(glm::translate(model, glm::vec3(-0.25f, 4.0f, -0.25f)), lightingShader, texture3);
		windowPyramidBig.draw(glm::translate(model, glm::vec3(-0.25f, 4.0f, 5.125f)), lightingShader, texture3);
		windowPyramidSmall.draw(glm::translate(model, glm::vec3(0.5f, 4.0f, 5.5f)), lightingShader, texture3);

		windowsLR.draw(glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0f)), lightingShader, texture9);
		windowsUD.draw(glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0f)), lightingShader, texture10);
		frontDoor.draw(glm::translate(model, glm::vec3(2.95f, 0.0f, 0.0f)), lightingShader, texture11);
		backStairs.draw(glm::translate(model, glm::vec3(5.0f, 0.0f, 0.0f)), lightingShader, texture5);
		backDoor.draw(glm::translate(model, glm::vec3(5.0f, 0.0f, 0.01f)), lightingShader, texture12);
		garageDoors.draw(glm::translate(model, glm::vec3(5.0f, 0.0f, 0.01f)), lightingShader, texture13);
		
		bushes.draw(glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0f)), lightingShader, texture14);
		// glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
		// -------------------------------------------------------------------------------
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	//clean up our mess
	plane.cleanUp();
	firstFloorBrick.cleanUp();
	firstFloorSiding.cleanUp();
	firstFloorRoof.cleanUp();
	porch.cleanUp();
	frontStairs.cleanUp();
	garage.cleanUp();
	porchCol.cleanUp();
	secondFloor.cleanUp();
	secondFloorRoof.cleanUp();
	windowPyramidBig.cleanUp();
	windowPyramidSmall.cleanUp();
	siding.cleanUp();
	porchFence.cleanUp();
	windowsLR.cleanUp();
	windowsUD.cleanUp();
	backStairs.cleanUp();
	backDoor.cleanUp();
	garageDoors.cleanUp();
	bushes.cleanUp();
	//pyramid.cleanUp();

	// glfw: terminate, clearing all previously allocated GLFW resources.
	// ------------------------------------------------------------------
	glfwTerminate();
	return 0;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow *window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	float movementSpeed = cameraSpeed * deltaTime;
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		cameraPos += movementSpeed * cameraFront;
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		cameraPos -= movementSpeed * cameraFront;
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * movementSpeed;
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * movementSpeed;
	if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS)
		cameraPos += movementSpeed * cameraUp;
	if (glfwGetKey(window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS)
		cameraPos -= movementSpeed * cameraUp;
	if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
		orthoView = !orthoView;

}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	// make sure the viewport matches the new window dimensions; note that width and 
	// height will be significantly larger than specified on retina displays.
	glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
	if (firstMouse)
	{
		lastX = xpos;
		lastY = ypos;
		firstMouse = false;
	}

	float xoffset = xpos - lastX;
	float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top
	lastX = xpos;
	lastY = ypos;

	float sensitivity = 0.1f; // change this value to your liking
	xoffset *= sensitivity;
	yoffset *= sensitivity;

	yaw += xoffset;
	pitch += yoffset;

	// make sure that when pitch is out of bounds, screen doesn't get flipped
	if (pitch > 89.0f)
		pitch = 89.0f;
	if (pitch < -89.0f)
		pitch = -89.0f;

	glm::vec3 front;
	front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
	front.y = sin(glm::radians(pitch));
	front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
	cameraFront = glm::normalize(front);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{

	cameraSpeed += yoffset;
	cameraSpeed = std::fmaxf(cameraSpeed, 1);
	cameraSpeed = std::fminf(cameraSpeed, 100);

}