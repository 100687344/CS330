#version 330 core
out vec4 FragColor;

in vec2 TexCoord;
in vec3 Normal;
in vec3 Position;

// texture samplers
uniform sampler2D texture1;
uniform sampler2D texture2;
uniform vec3 viewPos; 


void main()
{
	// linearly interpolate between both textures (80% container, 20% awesomeface)
	//FragColor = mix(texture(texture1, TexCoord), texture(texture2, TexCoord), 0.2);
	FragColor = texture(texture1, TexCoord);
	vec3 n = Normal;
	if(dot(viewPos - Position, n)< 0.0f)
		n= -n;
	FragColor = vec4(n, 1);
	//FragColor = vec4(1,0,0,1);
}